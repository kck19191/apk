// LEVIATHANIC 토큰 생성기 - 디스코드 API 통신 모듈
// 제작자 제프리 - https://discord.gg/leviathanic
//
// Unclaimed 토큰 생성 흐름:
//   1) /api/v9/experiments → fingerprint 획득 (세션 ID)
//   2) hCaptcha 해결 (CapSolver 호출)
//   3) /api/v9/auth/register 로 {fingerprint, username, captcha_key, ...} 전송
//      → 즉시 토큰 발급 (이메일/비밀번호 불필요)

package gg.leviathanic.levigen

import android.util.Base64
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.random.Random

object DiscordApi {
    private val JSON = "application/json; charset=utf-8".toMediaType()

    // User-Agent 풀 - 탐지 회피를 위한 분산용
    private val UA_POOL = listOf(
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    )

    private fun randomUA() = UA_POOL.random()

    /** base64 로 인코딩된 X-Super-Properties 헤더값 생성. */
    fun superProperties(ua: String = randomUA()): String {
        val props = JSONObject().apply {
            put("os", "Windows")
            put("browser", "Chrome")
            put("device", "")
            put("system_locale", "ko-KR")
            put("browser_user_agent", ua)
            put("browser_version", "126.0.0.0")
            put("os_version", "10")
            put("referrer", "")
            put("referring_domain", "")
            put("referrer_current", "")
            put("referring_domain_current", "")
            put("release_channel", "stable")
            put("client_build_number", 280000)
            put("client_event_source", JSONObject.NULL)
        }
        return Base64.encodeToString(props.toString().toByteArray(), Base64.NO_WRAP)
    }

    /** 프록시 문자열을 OkHttp Proxy 로 파싱. "http://user:pass@ip:port" 형식 지원. */
    private fun parseProxy(raw: String?): Pair<Proxy?, Authenticator?> {
        if (raw.isNullOrBlank()) return null to null
        val cleaned = raw.trim().removePrefix("http://").removePrefix("https://")

        // user:pass@host:port 에서 인증부와 호스트부 분리
        val (auth, hostPart) = if ("@" in cleaned) {
            val parts = cleaned.split("@", limit = 2)
            parts[0] to parts[1]
        } else null to cleaned

        val hostPort = hostPart.split(":", limit = 2)
        if (hostPort.size != 2) return null to null
        val host = hostPort[0]
        val port = hostPort[1].toIntOrNull() ?: return null to null
        val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress(host, port))

        // 프록시 Basic 인증 핸들러
        val authenticator: Authenticator? = if (auth != null && ":" in auth) {
            val (user, pass) = auth.split(":", limit = 2)
            Authenticator { _, response ->
                val cred = Credentials.basic(user, pass)
                response.request.newBuilder()
                    .header("Proxy-Authorization", cred)
                    .build()
            }
        } else null
        return proxy to authenticator
    }

    /** 프록시 적용된 OkHttpClient 인스턴스 생성. */
    private fun client(proxy: String?): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .retryOnConnectionFailure(false)
        val (p, auth) = parseProxy(proxy)
        if (p != null) {
            builder.proxy(p)
            if (auth != null) builder.proxyAuthenticator(auth)
        }
        return builder.build()
    }

    /**
     * fingerprint 획득 요청.
     * 디스코드가 register 전에 세션 ID 로 fingerprint 를 요구함.
     */
    fun fetchFingerprint(proxy: String? = null): String? {
        val ua = randomUA()
        val cl = client(proxy)
        return try {
            val req = Request.Builder()
                .url("https://discord.com/api/v9/experiments")
                .post(ByteArray(0).toRequestBody(JSON))
                .header("User-Agent", ua)
                .header("X-Super-Properties", superProperties(ua))
                .header("Content-Type", "application/json")
                .header("Accept-Language", "en-US,en;q=0.9")
                .header("Origin", "https://discord.com")
                .header("Referer", "https://discord.com/register")
                .build()
            cl.newCall(req).execute().use { r ->
                val body = r.body?.string() ?: return null
                JSONObject(body).optString("fingerprint").ifEmpty { null }
            }
        } catch (_: Exception) { null }
    }

    /** 무작위 username 생성 - Leviathanic_xxxxx 포맷. */
    fun randomUsername(): String = ProfileRandomizer.randomUsername()

    /** 무작위 생년월일 (1990~2003). */
    private fun randomDOB(): String {
        val y = Random.nextInt(1990, 2004)
        val m = Random.nextInt(1, 13)
        val d = Random.nextInt(1, 29)
        return String.format(Locale.US, "%04d-%02d-%02d", y, m, d)
    }

    /**
     * 토큰 등록 요청.
     * @param email 넘기면 email 인증형 가입, null 이면 unclaimed
     * @param password email 가입에 필요한 비밀번호
     * @return Pair<token, errorString> - 성공시 token 유효, 실패시 error 문자열
     */
    fun register(
        fingerprint: String,
        captchaKey: String,
        proxy: String? = null,
        email: String? = null,
        password: String? = null,
    ): Pair<String?, String?> {
        val ua = randomUA()
        val username = randomUsername()

        // 회원가입 페이로드 조립 - email 모드/unclaimed 모드 분기
        val payload = JSONObject().apply {
            put("fingerprint", fingerprint)
            put("username", username)
            put("invite", JSONObject.NULL)
            put("consent", true)
            put("date_of_birth", randomDOB())
            put("gift_code_sku_id", JSONObject.NULL)
            put("captcha_key", captchaKey)
            if (email != null) {
                put("email", email)
                put("password", password ?: "Px${System.nanoTime()}!A")
                put("promotional_email_opt_in", false)
            }
        }.toString()

        return try {
            val req = Request.Builder()
                .url("https://discord.com/api/v9/auth/register")
                .post(payload.toRequestBody(JSON))
                .header("User-Agent", ua)
                .header("X-Super-Properties", superProperties(ua))
                .header("X-Fingerprint", fingerprint)
                .header("Content-Type", "application/json")
                .header("Accept-Language", "en-US,en;q=0.9")
                .header("Origin", "https://discord.com")
                .header("Referer", "https://discord.com/register")
                .build()
            client(proxy).newCall(req).execute().use { r ->
                val body = r.body?.string() ?: return null to "empty"
                val j = JSONObject(body)
                val tok = j.optString("token")
                if (tok.isNotEmpty()) tok to null
                else null to body.take(200)
            }
        } catch (e: Exception) {
            null to (e.message ?: "exception").take(100)
        }
    }

    /** 토큰 유효성 검사 요청 (/users/@me 호출). */
    fun checkToken(token: String, proxy: String? = null): CheckResult {
        val ua = randomUA()
        return try {
            val req = Request.Builder()
                .url("https://discord.com/api/v9/users/@me")
                .get()
                .header("Authorization", token)
                .header("User-Agent", ua)
                .header("X-Super-Properties", superProperties(ua))
                .build()
            client(proxy).newCall(req).execute().use { r ->
                when (r.code) {
                    200 -> {
                        // 토큰 유효 → 계정 정보 추출
                        val j = JSONObject(r.body?.string() ?: "{}")
                        CheckResult(
                            status = "valid",
                            username = j.optString("username"),
                            id = j.optString("id"),
                            email = j.optString("email", null),
                            phone = j.optString("phone", null),
                            verified = j.optBoolean("verified", false),
                            mfa = j.optBoolean("mfa_enabled", false),
                            nitro = j.optInt("premium_type", 0),
                            flags = j.optInt("public_flags", 0),
                        )
                    }
                    401 -> CheckResult("invalid")        // 토큰 폐기됨
                    403 -> CheckResult("locked")         // 계정 잠김/정지
                    429 -> {
                        // 레이트 리밋 - retry_after 추출
                        val retry = try {
                            JSONObject(r.body?.string() ?: "{}")
                                .optDouble("retry_after", 2.0)
                        } catch (_: Exception) { 2.0 }
                        CheckResult("retry", retryAfter = retry)
                    }
                    else -> CheckResult("error", errorCode = r.code)
                }
            }
        } catch (_: Exception) {
            CheckResult("timeout")
        }
    }

    /** 토큰 체크 결과 데이터 클래스. */
    data class CheckResult(
        val status: String,     // valid / invalid / locked / retry / timeout / error
        val username: String? = null,
        val id: String? = null,
        val email: String? = null,
        val phone: String? = null,
        val verified: Boolean = false,
        val mfa: Boolean = false,
        val nitro: Int = 0,
        val flags: Int = 0,
        val retryAfter: Double = 0.0,
        val errorCode: Int = 0,
    ) {
        /** 세부 상태 분류 - 인증 진행 상태별. */
        val subStatus: String get() = when {
            status != "valid" -> status
            !verified && phone.isNullOrBlank() -> "unclaimed"        // 미인증
            !verified -> "phone_only"                                // 전화만 인증
            phone.isNullOrBlank() -> "email_only"                    // 메일만 인증
            else -> "fully_verified"                                 // 완전 인증
        }
    }
}
