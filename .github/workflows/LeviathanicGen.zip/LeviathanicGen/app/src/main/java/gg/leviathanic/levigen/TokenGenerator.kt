// LEVIATHANIC 토큰 생성기 - 병렬 생성 엔진
// 제작자 제프리 - https://discord.gg/leviathanic
//
// 아키텍처:
//   - 캡챠 워커 N개가 백그라운드에서 solution 큐를 지속 공급
//   - 생성 워커 M개가 큐에서 꺼내 → fingerprint → register 수행
//   - 상태는 Flow 로 UI 에 실시간 전송
//
// 처리량 = 캡챠 워커 수 / 15초 (hCaptcha 평균 응답 시간 기준)

package gg.leviathanic.levigen

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicInteger

class TokenGenerator(
    private val apiKey: String,              // 캡솔버 API 키
    private val proxies: List<String>,       // 프록시 풀 - 라운드로빈
    private val target: Int,                 // 목표 생성 개수
    private val captchaWorkers: Int = 40,       // 캡챠 워커 수
    private val genWorkers: Int = 25,           // 생성 워커 수
    private val autoVerify: Boolean = true,     // 자동 이메일 verify 여부
    private val autoHumanize: Boolean = true,   // 자동 프로필 랜덤화 여부
) {
    /** 로그 스트림용 엔트리 - 타임스탬프 + 토큰 + 상태 플래그. */
    data class TokenLog(
        val ts: Long,
        val token: String,
        val verified: Boolean = false,  // email verify 완료 여부
        val humanized: Boolean = false, // 프로필 랜덤화 완료 여부
    )

    /** UI 에 표시할 상태 스냅샷. */
    data class State(
        val ok: Int = 0,                                 // 성공 개수
        val fail: Int = 0,                               // 실패 개수
        val target: Int = 0,                             // 목표
        val captchaQueue: Int = 0,                       // 큐 대기 수
        val elapsedMs: Long = 0,                         // 경과 밀리초
        val rate: Double = 0.0,                          // 초당 성공률
        val errors: Map<String, Int> = emptyMap(),       // 오류 종류별 카운트
        val lastError: String = "",                      // 가장 최근 원시 에러
        val running: Boolean = false,                    // 실행중 여부
        val logs: List<TokenLog> = emptyList(),          // 최근 30개 로그
    ) {
        val done: Int get() = ok + fail
        val pct: Int get() = if (target == 0) 0 else (done * 100 / target)
    }

    private val _state = MutableStateFlow(State(target = target))
    val state: StateFlow<State> = _state.asStateFlow()

    // 생성 완료된 토큰 저장소 (뮤텍스 보호)
    private val tokens = mutableListOf<String>()
    private val tokensLock = Mutex()

    // 실시간 로그 스트림용 - 최대 30개 유지 (앞에서 추가, 초과시 뒤에서 제거)
    private val logStream = ArrayDeque<TokenLog>()
    private val logLock = Mutex()

    /** 로그 큐에 새 토큰 추가. */
    private suspend fun pushLog(token: String, verified: Boolean, humanized: Boolean) {
        logLock.withLock {
            logStream.addFirst(
                TokenLog(System.currentTimeMillis(), token, verified, humanized)
            )
            while (logStream.size > 30) logStream.removeLast()
        }
    }

    // 성공/실패 카운터 (원자 연산)
    private val okCount = AtomicInteger(0)
    private val failCount = AtomicInteger(0)

    // 오류 종류별 집계 (뮤텍스 보호)
    private val errors = mutableMapOf<String, Int>()
    private val errorsLock = Mutex()
    private var lastErr = ""

    private var scope: CoroutineScope? = null
    private var startTs = 0L

    // 캡챠 solution 공급 채널
    private val captchaQueue = Channel<Pair<String, String?>>(capacity = captchaWorkers * 2)

    // 프록시 라운드로빈 인덱스
    private var proxyIdx = 0
    private fun nextProxy(): String? {
        if (proxies.isEmpty()) return null
        val p = proxies[proxyIdx % proxies.size]
        proxyIdx++
        return p
    }

    /** 원시 에러 메시지를 한국어 카테고리로 분류. */
    private fun classify(err: String?): String {
        val s = (err ?: "").lowercase()
        return when {
            "fingerprint" in s -> "🔑 핑거프린트 획득 실패"
            "captcha_key" in s -> "🧩 캡챠 재검증 요청됨"
            "captcha" in s -> "🧩 캡챠 솔버 실패"
            "429" in s || "rate" in s || "ratelimit" in s -> "🚧 레이트 리밋"
            "403" in s || "forbidden" in s -> "🚫 IP 차단"
            "401" in s -> "🔒 인증 거부"
            "timeout" in s || "timed out" in s -> "⏱ 타임아웃"
            "proxy" in s || "connect" in s -> "🌐 프록시 오류"
            "503" in s || "unavailable" in s -> "💤 서버 응답 없음"
            s.isBlank() -> "❓ 알 수 없음"
            else -> "❓ ${s.take(40)}"
        }
    }

    /** 오류 카운트 기록. */
    private suspend fun recordError(msg: String?) {
        errorsLock.withLock {
            val cat = classify(msg)
            errors[cat] = (errors[cat] ?: 0) + 1
            if (!msg.isNullOrBlank()) lastErr = msg.take(80)
        }
    }

    /** 캡챠 워커 - 큐에 solution 을 지속 공급. */
    private suspend fun captchaWorker() {
        while (coroutineContext.isActive && okCount.get() + failCount.get() < target) {
            val proxy = nextProxy()
            val sol = withContext(Dispatchers.IO) {
                CapSolver.solveHCaptcha(apiKey = apiKey, proxy = proxy)
            }
            if (sol != null) {
                captchaQueue.send(sol to proxy)
            } else {
                recordError("captcha solve failed")
                delay(500)
            }
        }
    }

    /** 생성 워커 - 큐에서 solution 받아 → fingerprint → register → (옵션) verify. */
    private suspend fun generateWorker() {
        while (coroutineContext.isActive && okCount.get() + failCount.get() < target) {
            // 큐에서 캡챠 수신 (최대 60초 대기)
            val (captchaKey, proxy) = try {
                withTimeout(60_000) { captchaQueue.receive() }
            } catch (_: TimeoutCancellationException) {
                failCount.incrementAndGet()
                recordError("captcha queue timeout")
                continue
            }

            // ─ 1단계 : 임시 이메일 계정 생성 (autoVerify 모드만) ─
            val emailAcc = if (autoVerify) {
                withContext(Dispatchers.IO) { EmailVerifier.createAccount() }
            } else null

            // ─ 2단계 : fingerprint 획득 → register 요청 ─
            val (tok, err) = withContext(Dispatchers.IO) {
                val fp = DiscordApi.fetchFingerprint(proxy)
                    ?: return@withContext null to "fingerprint"
                DiscordApi.register(
                    fingerprint = fp,
                    captchaKey = captchaKey,
                    proxy = proxy,
                    email = emailAcc?.address,
                    password = emailAcc?.password,
                )
            }

            if (tok == null) {
                failCount.incrementAndGet()
                recordError(err)
                continue
            }

            // ─ 3단계 : 받은편지함 폴링 → verify 링크 추출 → GET 호출 ─
            var verified = false
            if (emailAcc != null) {
                val link = EmailVerifier.waitForVerifyLink(emailAcc, timeoutSec = 90)
                if (link != null) {
                    verified = withContext(Dispatchers.IO) {
                        EmailVerifier.hitVerifyLink(link)
                    }
                }
            }

            // ─ 4단계 : 프로필 랜덤화 (humanize) ─
            // 아바타/글로벌네임/bio/pronouns/accent_color 자동 세팅.
            // 봇처럼 안 보이게 사람 흉내 - 토큰 생존률 향상.
            var humanized = false
            if (autoHumanize) {
                humanized = ProfileRandomizer.humanize(tok, proxy)
            }

            okCount.incrementAndGet()
            tokensLock.withLock { tokens.add(tok) }
            pushLog(tok, verified, humanized)
        }
    }

    /** 상태 퍼블리셔 - 500ms 간격으로 UI 갱신. */
    private suspend fun progressPublisher() {
        while (coroutineContext.isActive) {
            delay(500)
            val now = System.currentTimeMillis()
            val elapsed = now - startTs
            val ok = okCount.get()
            val fail = failCount.get()
            val rate = if (elapsed > 0) ok * 1000.0 / elapsed else 0.0
            val errSnapshot = errorsLock.withLock { errors.toMap() }
            val logSnapshot = logLock.withLock { logStream.toList() }
            _state.value = State(
                ok = ok, fail = fail, target = target,
                captchaQueue = 0,  // Channel 사이즈 노출 API 없음
                elapsedMs = elapsed, rate = rate,
                errors = errSnapshot, lastError = lastErr,
                running = true, logs = logSnapshot,
            )
            if (ok + fail >= target) break
        }
    }

    /** 생성된 전체 토큰 리스트 반환. */
    suspend fun allTokens(): List<String> = tokensLock.withLock { tokens.toList() }

    /** 메인 실행 - 전체 워커 가동 + 완료 대기. */
    suspend fun run() = coroutineScope {
        scope = this
        startTs = System.currentTimeMillis()
        _state.value = _state.value.copy(running = true, target = target)

        // 워커 가동
        val captchaJobs = (1..captchaWorkers).map {
            launch(Dispatchers.IO) { captchaWorker() }
        }
        val genJobs = (1..genWorkers).map {
            launch(Dispatchers.IO) { generateWorker() }
        }
        val progressJob = launch { progressPublisher() }

        // 목표 수량 달성까지 대기
        while (okCount.get() + failCount.get() < target) {
            delay(500)
        }

        // 모든 워커 중단
        captchaJobs.forEach { it.cancel() }
        genJobs.forEach { it.cancel() }
        progressJob.cancel()

        // 최종 상태 발행
        _state.value = _state.value.copy(
            running = false,
            ok = okCount.get(),
            fail = failCount.get(),
            elapsedMs = System.currentTimeMillis() - startTs,
            errors = errors.toMap(),
            logs = logStream.toList(),
        )
    }

    /** 외부에서 중단 호출. */
    fun stop() {
        scope?.cancel()
    }
}
