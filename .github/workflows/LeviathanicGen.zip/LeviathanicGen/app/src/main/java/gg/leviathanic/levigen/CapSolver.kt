// LEVIATHANIC 토큰 생성기 - 캡솔버 통신 모듈
// 제작자 제프리 - https://discord.gg/leviathanic
//
// capsolver.com API 호출 - hCaptcha 해결 토큰 획득
// 1) /createTask 로 작업 등록 → taskId 받음
// 2) /getTaskResult 로 폴링 → ready 상태되면 solution 반환

package gg.leviathanic.levigen

import kotlinx.coroutines.delay
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object CapSolver {
    // JSON 요청 타입
    private val JSON = "application/json; charset=utf-8".toMediaType()

    // 전역 HTTP 클라이언트 - 재사용으로 TCP 연결 비용 절감
    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    // 디스코드 회원가입 페이지의 hCaptcha 사이트 키 (공개값)
    const val DISCORD_HCAPTCHA_SITEKEY = "f5561ba9-8f1e-40ca-9b5b-a0b3f719ef34"

    /**
     * hCaptcha 해결 요청.
     * @param apiKey 캡솔버 대시보드에서 발급받은 키
     * @param proxy 선택값 - "http://user:pass@ip:port" 또는 "http://ip:port"
     * @return 해결된 토큰 문자열, 실패시 null
     */
    suspend fun solveHCaptcha(
        apiKey: String,
        siteKey: String = DISCORD_HCAPTCHA_SITEKEY,
        url: String = "https://discord.com/register",
        proxy: String? = null,
        timeoutSec: Int = 180,
    ): String? {
        // 1단계) 작업 등록 페이로드 조립
        val task = JSONObject().apply {
            if (proxy.isNullOrBlank()) {
                put("type", "HCaptchaTaskProxyLess")
            } else {
                put("type", "HCaptchaTask")
                put("proxy", proxy)
            }
            put("websiteURL", url)
            put("websiteKey", siteKey)
        }
        val createBody = JSONObject().apply {
            put("clientKey", apiKey)
            put("task", task)
        }.toString()

        val createReq = Request.Builder()
            .url("https://api.capsolver.com/createTask")
            .post(createBody.toRequestBody(JSON))
            .build()

        // 작업 등록 요청 → taskId 추출
        val taskId = try {
            client.newCall(createReq).execute().use { r ->
                val body = r.body?.string() ?: return null
                val j = JSONObject(body)
                if (j.optInt("errorId", -1) != 0) return null
                j.optString("taskId").ifEmpty { return null }
            }
        } catch (e: Exception) {
            return null
        }

        // 2단계) 결과 폴링 - 3초 간격으로 timeoutSec 초까지
        val start = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutSec * 1000L) {
            delay(3000)
            try {
                val pollBody = JSONObject().apply {
                    put("clientKey", apiKey)
                    put("taskId", taskId)
                }.toString()
                val pollReq = Request.Builder()
                    .url("https://api.capsolver.com/getTaskResult")
                    .post(pollBody.toRequestBody(JSON))
                    .build()
                client.newCall(pollReq).execute().use { r ->
                    val body = r.body?.string() ?: return@use
                    val j = JSONObject(body)
                    // 작업 완료 → solution 에서 토큰 추출
                    if (j.optString("status") == "ready") {
                        val sol = j.optJSONObject("solution") ?: return null
                        return sol.optString("gRecaptchaResponse")
                            .ifEmpty { sol.optString("token") }
                            .ifEmpty { null }
                    }
                    // 서버 측 에러 반환 → 즉시 중단
                    if (j.optInt("errorId", 0) != 0) return null
                }
            } catch (_: Exception) { /* 네트워크 일시 오류는 재시도 */ }
        }
        return null  // 타임아웃
    }

    /** 잔액 조회 - 설정 화면/대시보드 용도. */
    suspend fun getBalance(apiKey: String): Double? {
        return try {
            val body = JSONObject().apply { put("clientKey", apiKey) }.toString()
            val req = Request.Builder()
                .url("https://api.capsolver.com/getBalance")
                .post(body.toRequestBody(JSON))
                .build()
            client.newCall(req).execute().use { r ->
                val s = r.body?.string() ?: return null
                val j = JSONObject(s)
                if (j.optInt("errorId", -1) != 0) null
                else j.optDouble("balance", Double.NaN).takeIf { !it.isNaN() }
            }
        } catch (_: Exception) { null }
    }
}
