// LEVIATHANIC 토큰 생성기 - 자동 이메일 인증 모듈
// 제작자 제프리 - https://discord.gg/leviathanic
//
// mail.tm REST API 를 사용한 자동 verify 흐름:
//   1) 임시 이메일 생성 (/accounts)
//   2) JWT 토큰 획득 (/token)
//   3) 디스코드 /register 에 이 이메일로 가입
//   4) 받은편지함 폴링 (/messages) → 디스코드 verify 메일 수신
//   5) 본문에서 verify 링크 추출 → GET 호출 → 인증 완료
//
// 참고: nsfws/BongoTokenGenerator (mail.tm 사용 패턴),
//      Vinyzu/DiscordGenerator (unclaimed 토큰 생성 흐름)

package gg.leviathanic.levigen

import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.random.Random

object EmailVerifier {
    private val JSON = "application/json; charset=utf-8".toMediaType()

    // mail.tm 과 mail.gw 둘 다 동일 스키마 - 하나 다운되면 자동 fallback
    private val PROVIDERS = listOf(
        "https://api.mail.tm",
        "https://api.mail.gw",
    )

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    /** 임시 이메일 계정 1개. */
    data class Account(
        val provider: String,   // 선택된 공급자 베이스 URL
        val address: String,    // name@domain
        val password: String,
        val jwt: String,        // 받은편지함 조회용 Bearer
    )

    /** 문자/숫자 혼합 랜덤 ID. */
    private fun randomLocal(len: Int = 12): String {
        val pool = "abcdefghijklmnopqrstuvwxyz0123456789"
        return buildString(len) { repeat(len) { append(pool.random()) } }
    }

    /** 사용 가능한 도메인 목록 조회. */
    private fun fetchDomain(provider: String): String? {
        return try {
            val req = Request.Builder().url("$provider/domains").get().build()
            client.newCall(req).execute().use { r ->
                if (r.code != 200) return null
                val body = r.body?.string() ?: return null
                // hydra:member 배열에서 첫 활성 도메인 추출
                val j = JSONObject(body)
                val members = j.optJSONArray("hydra:member") ?: JSONArray()
                for (i in 0 until members.length()) {
                    val d = members.getJSONObject(i)
                    if (d.optBoolean("isActive", true)) {
                        return d.optString("domain")
                    }
                }
                null
            }
        } catch (_: Exception) { null }
    }

    /**
     * 임시 이메일 계정 생성 + JWT 획득.
     * mail.tm → mail.gw 순차 fallback.
     */
    fun createAccount(): Account? {
        for (provider in PROVIDERS) {
            val domain = fetchDomain(provider) ?: continue
            val address = "${randomLocal()}@$domain"
            val password = "Px${Random.nextLong(100000, 999999)}!A"

            // 계정 생성
            val createBody = JSONObject().apply {
                put("address", address)
                put("password", password)
            }.toString()
            val createReq = Request.Builder()
                .url("$provider/accounts")
                .post(createBody.toRequestBody(JSON))
                .build()
            val created = try {
                client.newCall(createReq).execute().use { it.code in 200..201 }
            } catch (_: Exception) { false }
            if (!created) continue

            // JWT 토큰 획득
            val tokenReq = Request.Builder()
                .url("$provider/token")
                .post(createBody.toRequestBody(JSON))
                .build()
            val jwt = try {
                client.newCall(tokenReq).execute().use { r ->
                    if (r.code != 200) null
                    else JSONObject(r.body?.string() ?: "{}").optString("token").ifEmpty { null }
                }
            } catch (_: Exception) { null } ?: continue

            return Account(provider, address, password, jwt)
        }
        return null
    }

    /**
     * 받은편지함에서 디스코드 verify 메일 대기 + 본문에서 링크 추출.
     * @param timeoutSec 최대 대기 시간
     */
    suspend fun waitForVerifyLink(acc: Account, timeoutSec: Int = 120): String? {
        return withTimeoutOrNull(timeoutSec * 1000L) {
            var attempts = 0
            while (true) {
                attempts++
                try {
                    val listReq = Request.Builder()
                        .url("${acc.provider}/messages")
                        .header("Authorization", "Bearer ${acc.jwt}")
                        .get()
                        .build()

                    val msgIds = client.newCall(listReq).execute().use { r ->
                        if (r.code != 200) return@use emptyList<String>()
                        val j = JSONObject(r.body?.string() ?: "{}")
                        val arr = j.optJSONArray("hydra:member") ?: return@use emptyList<String>()
                        (0 until arr.length()).mapNotNull { i ->
                            val m = arr.getJSONObject(i)
                            // 디스코드에서 온 메일만 필터링
                            val from = m.optJSONArray("from")?.optJSONObject(0)
                                ?.optString("address", "") ?: ""
                            if ("discord" in from.lowercase()) m.optString("id") else null
                        }
                    }

                    for (mid in msgIds) {
                        val detailReq = Request.Builder()
                            .url("${acc.provider}/messages/$mid")
                            .header("Authorization", "Bearer ${acc.jwt}")
                            .get()
                            .build()
                        val body = client.newCall(detailReq).execute().use { r ->
                            if (r.code != 200) null else r.body?.string()
                        } ?: continue

                        // text + html 전체에서 verify 링크 패턴 검색
                        val link = extractVerifyLink(body)
                        if (link != null) return@withTimeoutOrNull link
                    }
                } catch (_: Exception) { /* 폴링 중 네트워크 오류 무시 */ }
                delay(3000)
            }
            @Suppress("UNREACHABLE_CODE") null
        }
    }

    /** JSON 본문에서 디스코드 verify 링크 추출. */
    private fun extractVerifyLink(bodyJson: String): String? {
        val patterns = listOf(
            Regex("""https://click\.discord\.com/ls/click\?[^\s"'<>]+"""),
            Regex("""https://discord\.com/verify[^\s"'<>]+"""),
            Regex("""https://discord\.com/mail[^\s"'<>]+"""),
        )
        for (pat in patterns) {
            val m = pat.find(bodyJson)
            if (m != null) return m.value
        }
        return null
    }

    /** verify 링크 호출 → 리다이렉트 쿼리에서 verification_token 추출 */
    fun hitVerifyLink(link: String): Boolean {
        return try {
            val req = Request.Builder().url(link).get().build()
            client.newCall(req).execute().use { r ->
                // click.discord.com 이면 리다이렉트 → verify 페이지
                r.code in 200..399
            }
        } catch (_: Exception) { false }
    }
}
