# Leviathanic

discord 토큰 생성기 + 체커 + 레이더 (안드로이드)

## 기능

- **생성** — unclaimed 토큰 자동 생성 (캡솔버 + 프록시)
  - mail.tm / mail.gw 로 자동 이메일 verify
  - DiceBear shapes 아바타 + Leviathanic_xxxxx 유저네임 자동 세팅
  - bio 400개 풀에서 랜덤 + pronouns 실빈도 가중치
  - Hypesquad 뱃지 자동 부여
- **체커** — 토큰 valid/locked/invalid 분류 + 니트로/이메일 인증 조회
- **레이더** — 다수 토큰으로 공격 (서버 조인 / DM 폭격 / 리액션 / 채널 도배 / 멘션 폭격)
- **라이센스** — 관리자 발급형 (유효기간 + 최대 토큰 수 지정)
- **BGM** — 하드테크 트랙 랜덤 재생 (CXH / Akuran / RAGING_WOLF)

## 라이센스 시스템

### 관리자 - 라이센스 발급
1. 앱 실행 → 라이센스 입력 화면
2. 하단 "관리자 패널" 터치
3. 비밀키 입력: `Kcg505050g!`
4. 발급 폼: 사용자 / 유효 기간(일) / 최대 토큰 수
5. "라이센스 발급" → 생성된 키 복사 → 유저에게 전달

### 유저 - 라이센스 입력
1. 앱 실행 → 받은 라이센스 키 붙여넣기
2. 확인 → 메인 화면
3. 라이센스 정보는 상단에 표시 (`사용자 · D-30 · ≤5000`)

### 작동 방식
- HMAC-SHA256 오프라인 검증
- 라이센스 포맷: `base64url(payload).base64url(signature)`
- payload: `{u: 사용자, e: 만료 Epoch ms, m: 최대 토큰}`
- 앱/관리자 둘 다 같은 HMAC 키 내장 (APK 디컴파일하면 노출됨 - 오프라인의 한계)

## 빌드

### 방법 1 - GitHub Actions (권장, 환경 세팅 없음)
1. 이 프로젝트를 깃허브 레포에 푸시
2. Actions 탭에서 "Build APK" workflow 자동 실행
3. 완료되면 Artifacts 에서 `leviathanic-debug-apk.zip` 다운로드

### 방법 2 - 로컬 Android Studio
1. Android Studio Flamingo 이상 설치
2. 프로젝트 열기 → sync 대기
3. Build → Build APK(s)

### 방법 3 - CLI
```bash
./gradlew assembleDebug
# 결과: app/build/outputs/apk/debug/app-debug.apk
```

## 내장 기본값

`MainActivity.kt` 상단:
- `K_CAP` — CAPSOLVER API 키
- `K_PROXY` — 프록시
- `CAPTCHA_WORKERS = 40` — 캡챠 워커 수
- `GEN_WORKERS = 25` — 생성 워커 수

`License.kt`:
- `HMAC_KEY` — 라이센스 서명키
- `ADMIN_SECRET = "Kcg505050g!"` — 관리자 패널 비밀번호

## 테스트

### 로컬 검증 범위
각 모듈은 OkHttp 기반 순수 함수. 실제 디스코드 API + 캡솔버 결제 + 실 프록시가 필요해 샌드박스에서는 돌리지 않음. 실기기/에뮬레이터에서 APK 설치 후:

1. 라이센스 발급 → 입력 → 메인 진입
2. 생성 탭: 수량 10개 → 시작 → 로그에 v/h 플래그 확인
3. 체커 탭: 생성된 토큰 붙여넣기 → 분류 확인
4. 레이더 탭: 공격 유형 선택 → 타겟 입력 → 공격

### 레이더 테러 기능
- JOIN: 초대 코드 (예: `https://discord.gg/abc123` 또는 `abc123`)
- DM 폭격: 유저 ID (디스코드 개발자 모드로 복사)
- 리액션: `채널ID:메시지ID` 포맷 + 이모지
- 채널 도배: 채널 ID + 메시지
- 멘션 폭격: 채널 ID + @everyone 포함 메시지

## 구조

```
app/src/main/
├── AndroidManifest.xml
├── res/
│   ├── raw/           ← BGM mp3 3개
│   ├── drawable/      ← 로고
│   └── values/, xml/
└── java/gg/leviathanic/levigen/
    ├── MainActivity.kt           ← Compose UI + 라이센스 게이트 + 관리자 패널
    ├── License.kt                ← HMAC 라이센스 발급/검증
    ├── BgmPlayer.kt              ← MediaPlayer 랜덤 재생
    ├── TokenGenerator.kt         ← 병렬 생성 엔진
    ├── TokenChecker.kt           ← 체커
    ├── TokenRaider.kt            ← 레이더 (공격)
    ├── DiscordApi.kt             ← 디스코드 API 통신
    ├── CapSolver.kt              ← hCaptcha 솔버
    ├── EmailVerifier.kt          ← mail.tm/mail.gw 자동 verify
    └── ProfileRandomizer.kt      ← 프로필 + Hypesquad 자동
```

---
제프리 / discord.gg/leviathanic
