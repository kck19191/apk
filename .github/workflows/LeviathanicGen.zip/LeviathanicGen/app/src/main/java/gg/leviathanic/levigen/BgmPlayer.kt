// LEVIATHANIC 토큰 생성기 - BGM 플레이어 (하드테크 바이브)
// 제작자 제프리 - https://discord.gg/leviathanic
//
// res/raw 에 저장된 하드테크 트랙 랜덤 재생.
// 앱 포그라운드 동안만 재생, 백그라운드 전환시 pause.

package gg.leviathanic.levigen

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer

object BgmPlayer {
    // res/raw 트랙 ID 리스트 (R 는 실제 빌드시 생성됨)
    private val tracks = listOf(
        R.raw.bgm_terranova,
        R.raw.bgm_moon,
        R.raw.bgm_wolf,
    )

    private var player: MediaPlayer? = null
    private var currentIdx = -1
    private var muted = false

    /** 재생 시작 - 앱 시작시 호출. */
    fun start(ctx: Context) {
        if (player?.isPlaying == true) return
        if (muted) return
        playNext(ctx)
    }

    private fun playNext(ctx: Context) {
        try {
            currentIdx = (currentIdx + 1) % tracks.size
            player?.release()
            val p = MediaPlayer.create(ctx, tracks[currentIdx]) ?: return
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            p.setVolume(0.4f, 0.4f)  // 40% 볼륨 - 너무 크지 않게
            p.setOnCompletionListener { playNext(ctx) }  // 다음 트랙 자동 재생
            p.start()
            player = p
        } catch (_: Exception) { /* 재생 실패 - 다음 턴에 재시도 */ }
    }

    /** 일시정지 - 앱 백그라운드 전환시. */
    fun pause() {
        try { player?.pause() } catch (_: Exception) {}
    }

    /** 재개. */
    fun resume() {
        if (muted) return
        try { player?.start() } catch (_: Exception) {}
    }

    /** 음소거 토글. */
    fun toggleMute(ctx: Context): Boolean {
        muted = !muted
        if (muted) {
            try { player?.pause() } catch (_: Exception) {}
        } else {
            if (player == null) start(ctx) else try { player?.start() } catch (_: Exception) {}
        }
        return muted
    }

    fun isMuted(): Boolean = muted

    /** 완전 종료. */
    fun release() {
        try {
            player?.stop()
            player?.release()
        } catch (_: Exception) {}
        player = null
    }
}
