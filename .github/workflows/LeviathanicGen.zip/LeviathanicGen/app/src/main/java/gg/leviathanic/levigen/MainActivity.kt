// LEVIATHANIC 토큰 생성기 - 메인 액티비티
// 제작자 제프리 - https://discord.gg/leviathanic

package gg.leviathanic.levigen

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// 내부 설정값 - 유저 UI 에는 노출 안함
private const val K_CAP =
    "CAP-85B3F0DB916C6661E4B9E5B95ABB43D4E24662303820EF7DF3BDFD1BE45A4E46"
private const val K_PROXY =
    "http://np_47cxdxte2h-country-KR:hgeixjGmR2irSmkX@global.nodeproxies.xyz:8080"

private const val CAPTCHA_WORKERS = 40
private const val GEN_WORKERS = 25

// 테마 색상 - 시스템 다크/라이트 모드 자동 반영
// (isSystemInDarkTheme import 는 상단 import 블록으로 이동)

// 공통 색상 (양 모드 동일) - 상태색/터미널 톤
val navyBase   = Color(0xFF142D5C)   // 로고 네이비
val navyLight  = Color(0xFF3B5A9D)   // 다크모드용 더 밝은 액센트
val success    = Color(0xFF34A853)
val danger     = Color(0xFFD93025)
val termBg     = Color(0xFF0A1428)
val termTime   = Color(0xFF6E86B8)
val termTok    = Color(0xFF6EE7B7)
val termHash   = Color(0xFF4A5A80)

// 라이트 팔레트
private val lBg        = Color(0xFFF7F7F8)
private val lCard      = Color(0xFFFFFFFF)
private val lTextMain  = Color(0xFF14141A)
private val lTextSub   = Color(0xFF8E8E93)
private val lBorder    = Color(0xFFE5E5EA)

// 다크 팔레트
private val dBg        = Color(0xFF0B0B10)
private val dCard      = Color(0xFF16161D)
private val dTextMain  = Color(0xFFF0EFF3)
private val dTextSub   = Color(0xFF8B8898)
private val dBorder    = Color(0xFF262630)

// 시스템 모드에 따라 자동 반환하는 property getter
val bg: Color @Composable get() = if (isSystemInDarkTheme()) dBg else lBg
val card: Color @Composable get() = if (isSystemInDarkTheme()) dCard else lCard
val textMain: Color @Composable get() = if (isSystemInDarkTheme()) dTextMain else lTextMain
val textSub: Color @Composable get() = if (isSystemInDarkTheme()) dTextSub else lTextSub
val borderCol: Color @Composable get() = if (isSystemInDarkTheme()) dBorder else lBorder
// 액센트 - 다크모드에서 더 밝은 네이비
val accent: Color @Composable get() = if (isSystemInDarkTheme()) navyLight else navyBase

// ─ 반응형 치수 ────────────────────────────────────────────────
// 기기 폭 기준으로 패딩/폰트 자동 조정.
// 작은폰(<360dp): 타이트, 일반폰(360~600): 기본, 태블릿(>600): 중앙+최대폭.
@Composable
fun adaptivePaddingH(): Dp {
    val w = LocalConfiguration.current.screenWidthDp
    return when {
        w < 340 -> 14.dp
        w < 400 -> 20.dp
        w > 600 -> ((w - 480) / 2).coerceAtLeast(28).dp
        else -> 24.dp
    }
}

@Composable
fun adaptiveMaxWidth(): Dp {
    val w = LocalConfiguration.current.screenWidthDp
    return if (w > 600) 520.dp else Dp.Unspecified
}

/** 폰트 스케일 - 작은 폰에서 약간 축소. */
@Composable
fun adaptiveFontScale(): Float {
    val w = LocalConfiguration.current.screenWidthDp
    return when {
        w < 340 -> 0.92f
        w > 600 -> 1.05f
        else -> 1.0f
    }
}

enum class Tab(val label: String) {
    GENERATE("생성"),
    CHECK("체커"),
    RAID("레이더"),
}

enum class ExportFormat(val label: String, val desc: String) {
    TOKEN_ONLY("토큰만", "token"),
    EMAIL_PASS("이메일:비번", "email:pass"),
    FULL("이메일:비번:토큰", "email:pass:token"),
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // 시스템 설정에 따라 다크/라이트 자동 전환
            val dark = isSystemInDarkTheme()
            val scheme = if (dark) {
                darkColorScheme(
                    primary = navyLight, background = dBg, surface = dCard,
                    onBackground = dTextMain, onSurface = dTextMain,
                )
            } else {
                lightColorScheme(
                    primary = navyBase, background = lBg, surface = lCard,
                    onBackground = lTextMain, onSurface = lTextMain,
                )
            }
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = bg) { GateScreen() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        BgmPlayer.resume()
    }

    override fun onPause() {
        super.onPause()
        BgmPlayer.pause()
    }

    override fun onDestroy() {
        BgmPlayer.release()
        super.onDestroy()
    }
}

// ═════════════════════════════════════════════════════════════
//  [게이트] 라이센스 입력 → 관리자 패널 → 메인
// ═════════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GateScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current

    var mode by remember { mutableStateOf("gate") }  // gate / admin / main
    var licenseInfo by remember { mutableStateOf<License.Info?>(null) }

    // 저장된 라이센스 자동 확인
    LaunchedEffect(Unit) {
        val saved = License.load(ctx)
        if (saved.isNotEmpty()) {
            val info = License.verify(saved)
            if (info.valid) {
                licenseInfo = info
                mode = "main"
                BgmPlayer.start(ctx)
            }
        }
    }

    when (mode) {
        "main"  -> RootScreen(licenseInfo) { mode = "gate"; licenseInfo = null; License.clear(ctx) }
        "admin" -> AdminPanel(onBack = { mode = "gate" })
        else    -> LicenseInput(
            onVerified = { info ->
                licenseInfo = info
                mode = "main"
                BgmPlayer.start(ctx)
            },
            onAdmin = { mode = "admin" },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LicenseInput(onVerified: (License.Info) -> Unit, onAdmin: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var input by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var showAdminPrompt by remember { mutableStateOf(false) }
    var adminPw by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = adaptivePaddingH())
            .widthIn(max = adaptiveMaxWidth())
            .padding(top = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // 로고
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Image(
                painter = painterResource(R.drawable.logo_square),
                contentDescription = null,
                modifier = Modifier.size(56.dp).clip(RoundedCornerShape(12.dp))
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Leviathanic",
            modifier = Modifier.fillMaxWidth(),
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = textMain,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        Text(
            "라이센스를 입력하세요",
            modifier = Modifier.fillMaxWidth(),
            fontSize = 13.sp,
            color = textSub,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = input,
            onValueChange = { input = it; err = "" },
            placeholder = { Text("라이센스 키", fontSize = 13.sp, color = textSub) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = false, minLines = 2,
            textStyle = androidx.compose.ui.text.TextStyle(
                fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = textMain,
            ),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = accent, unfocusedBorderColor = borderCol, cursorColor = accent,
                focusedContainerColor = card, unfocusedContainerColor = card,
            ),
            shape = RoundedCornerShape(12.dp),
        )
        if (err.isNotEmpty()) {
            Text(err, fontSize = 12.sp, color = danger)
        }
        Button(
            onClick = {
                val info = License.verify(input)
                if (info.valid) {
                    License.save(ctx, input.trim())
                    onVerified(info)
                } else {
                    err = when (info.reason) {
                        "expired" -> "만료된 라이센스입니다"
                        "signature mismatch" -> "유효하지 않은 라이센스입니다"
                        "empty" -> "라이센스를 입력하세요"
                        else -> "라이센스 형식이 잘못됐습니다"
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.White),
            shape = RoundedCornerShape(12.dp),
        ) { Text("확인", fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }

        Spacer(Modifier.weight(1f))

        // 작게 - 관리자 패널
        Text(
            "관리자 패널",
            modifier = Modifier
                .fillMaxWidth()
                .clickable { showAdminPrompt = true }
                .padding(bottom = 32.dp),
            fontSize = 11.sp,
            color = textSub,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }

    // 관리자 비밀번호 다이얼로그
    if (showAdminPrompt) {
        AlertDialog(
            onDismissRequest = { showAdminPrompt = false; adminPw = "" },
            title = { Text("관리자 인증", fontSize = 15.sp) },
            text = {
                Column {
                    OutlinedTextField(
                        value = adminPw, onValueChange = { adminPw = it },
                        placeholder = { Text("비밀키") },
                        singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace),
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (adminPw == License.ADMIN_SECRET) {
                        showAdminPrompt = false; adminPw = ""; onAdmin()
                    } else {
                        adminPw = ""
                    }
                }) { Text("진입", color = accent) }
            },
            dismissButton = {
                TextButton(onClick = { showAdminPrompt = false; adminPw = "" }) {
                    Text("취소", color = textSub)
                }
            },
            containerColor = card,
        )
    }
}

// ═════════════════════════════════════════════════════════════
//  [관리자] 라이센스 발급 패널
// ═════════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminPanel(onBack: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var user by remember { mutableStateOf("") }
    var days by remember { mutableStateOf("30") }
    var maxTokens by remember { mutableStateOf("5000") }
    var issuedLicense by remember { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = adaptivePaddingH(), vertical = 32.dp).widthIn(max = adaptiveMaxWidth()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "← 뒤로",
                fontSize = 13.sp, color = textSub,
                modifier = Modifier.clickable(onClick = onBack),
            )
            Spacer(Modifier.weight(1f))
        }
        Spacer(Modifier.height(4.dp))
        Text("관리자 패널", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = textMain)
        Text("라이센스 발급", fontSize = 13.sp, color = textSub)

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = user, onValueChange = { user = it },
            label = { Text("사용자", fontSize = 12.sp) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = accent, unfocusedBorderColor = borderCol, cursorColor = accent,
                focusedContainerColor = card, unfocusedContainerColor = card,
            ),
            shape = RoundedCornerShape(10.dp),
        )
        OutlinedTextField(
            value = days, onValueChange = { days = it.filter { c -> c.isDigit() }.take(4) },
            label = { Text("유효 기간 (일)", fontSize = 12.sp) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = accent, unfocusedBorderColor = borderCol, cursorColor = accent,
                focusedContainerColor = card, unfocusedContainerColor = card,
            ),
            shape = RoundedCornerShape(10.dp),
        )
        OutlinedTextField(
            value = maxTokens, onValueChange = { maxTokens = it.filter { c -> c.isDigit() }.take(6) },
            label = { Text("최대 토큰 수 (0=무제한)", fontSize = 12.sp) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = accent, unfocusedBorderColor = borderCol, cursorColor = accent,
                focusedContainerColor = card, unfocusedContainerColor = card,
            ),
            shape = RoundedCornerShape(10.dp),
        )

        Button(
            onClick = {
                val u = user.ifEmpty { "user" }
                val d = days.toIntOrNull() ?: 30
                val m = maxTokens.toIntOrNull() ?: 0
                issuedLicense = License.issue(u, d, m)
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.White),
            shape = RoundedCornerShape(10.dp),
        ) { Text("라이센스 발급", fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }

        if (issuedLicense.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("발급된 라이센스", fontSize = 12.sp, color = textSub)
            Box(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(termBg)
                    .padding(14.dp),
            ) {
                Text(
                    issuedLicense,
                    fontSize = 10.sp,
                    color = termTok,
                    fontFamily = FontFamily.Monospace,
                )
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("license", issuedLicense))
                    Toast.makeText(ctx, "클립보드에 복사됨", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth().height(46.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, borderCol),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = textMain),
                shape = RoundedCornerShape(10.dp),
            ) { Text("복사", fontSize = 14.sp) }
        }
    }
}

@Composable
private fun RootScreen(license: License.Info?, onLogout: () -> Unit) {
    var tab by remember { mutableStateOf(Tab.GENERATE) }

    Column(Modifier.fillMaxSize().background(bg)) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                Tab.GENERATE -> GenerateScreen(license, onLogout)
                Tab.CHECK    -> CheckScreen()
                Tab.RAID     -> RaidScreen()
            }
        }
        BottomNav(current = tab, onSelect = { tab = it })
    }
}

// ─ 하단 네비 ─
@Composable
private fun BottomNav(current: Tab, onSelect: (Tab) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(card)
            .border(1.dp, borderCol, RoundedCornerShape(0.dp))
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        Tab.values().forEach { t ->
            val selected = t == current
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelect(t) }
                    .padding(horizontal = 18.dp, vertical = 6.dp),
            ) {
                Box(
                    Modifier
                        .size(6.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (selected) accent else Color.Transparent)
                )
                Spacer(Modifier.height(5.dp))
                Text(
                    t.label,
                    fontSize = 12.sp,
                    color = if (selected) accent else textSub,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                )
            }
        }
    }
}

// ═════════════════════════════════════════════════════════════
//  [탭1] 생성 화면
// ═════════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GenerateScreen(license: License.Info?, onLogout: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var amount by remember { mutableStateOf("500") }
    var gen by remember { mutableStateOf<TokenGenerator?>(null) }
    val state = gen?.state?.collectAsState()?.value
    var done by remember { mutableStateOf(false) }

    // 최대 토큰 제한 - 0이면 무제한
    val maxAllowed = license?.maxTokens ?: 0
    val requested = amount.toIntOrNull() ?: 0
    val overLimit = maxAllowed > 0 && requested > maxAllowed

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = adaptivePaddingH(), vertical = 28.dp).widthIn(max = adaptiveMaxWidth()),
    ) {
        TopBarWithLicense(license, onLogout, ctx)

        Spacer(Modifier.height(20.dp))

        when {
            state == null && !done -> IdleView(
                amount = amount,
                onAmountChange = { amount = it.filter { c -> c.isDigit() }.take(5) },
                overLimit = overLimit, maxAllowed = maxAllowed,
                onStart = {
                    val n = amount.toIntOrNull()?.coerceAtLeast(1) ?: return@IdleView
                    if (maxAllowed > 0 && n > maxAllowed) return@IdleView
                    done = false
                    val g = TokenGenerator(
                        apiKey = K_CAP,
                        proxies = listOf(K_PROXY),
                        target = n,
                        captchaWorkers = CAPTCHA_WORKERS,
                        genWorkers = GEN_WORKERS,
                    )
                    gen = g
                    scope.launch {
                        g.run()
                        saveTokens(ctx, g.allTokens())
                        done = true
                    }
                },
            )
            state != null && state.running -> RunView(state) {
                gen?.stop(); done = true
            }
            else -> DoneView(
                state = state,
                ctx = ctx,
                onAgain = { gen = null; done = false },
            )
        }

        Spacer(Modifier.weight(1f))
    }
}

/** 로고 + 라이센스 상태칩 + BGM 음소거 + 로그아웃. */
@Composable
private fun TopBarWithLicense(license: License.Info?, onLogout: () -> Unit, ctx: Context) {
    var muted by remember { mutableStateOf(BgmPlayer.isMuted()) }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Image(
            painter = painterResource(R.drawable.logo_square),
            contentDescription = null,
            modifier = Modifier.size(30.dp).clip(RoundedCornerShape(7.dp))
        )
        Spacer(Modifier.width(9.dp))
        Column {
            Text("Leviathanic", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = textMain)
            if (license != null) {
                Text(
                    "${license.user} · D-${license.daysLeft}" +
                        if (license.maxTokens > 0) " · ≤${license.maxTokens}" else "",
                    fontSize = 10.sp, color = textSub, fontFamily = FontFamily.Monospace,
                )
            }
        }
        Spacer(Modifier.weight(1f))
        // BGM 음소거 토글
        Box(
            Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(50))
                .background(if (muted) Color.Transparent else card)
                .border(1.dp, borderCol, RoundedCornerShape(50))
                .clickable { muted = BgmPlayer.toggleMute(ctx) },
            contentAlignment = Alignment.Center,
        ) {
            Text(
                if (muted) "🔇" else "🎵",
                fontSize = 14.sp,
            )
        }
        Spacer(Modifier.width(6.dp))
        Text(
            "⎋",
            fontSize = 16.sp, color = textSub,
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .clickable(onClick = onLogout)
                .padding(8.dp),
        )
    }
}

@Composable
private fun TopBar() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(R.drawable.logo_square),
            contentDescription = null,
            modifier = Modifier.size(32.dp).clip(RoundedCornerShape(7.dp))
        )
        Spacer(Modifier.width(10.dp))
        Text(
            "Leviathanic",
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
            color = textMain,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IdleView(
    amount: String, onAmountChange: (String) -> Unit,
    overLimit: Boolean = false, maxAllowed: Int = 0,
    onStart: () -> Unit,
) {
    Column {
        Text("생성 수량", fontSize = 13.sp, color = textSub)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = amount,
            onValueChange = onAmountChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            isError = overLimit,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            textStyle = androidx.compose.ui.text.TextStyle(
                fontSize = 24.sp,
                color = if (overLimit) danger else textMain,
                fontWeight = FontWeight.Medium,
            ),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = if (overLimit) danger else accent,
                unfocusedBorderColor = if (overLimit) danger else borderCol,
                cursorColor = accent, focusedContainerColor = card, unfocusedContainerColor = card,
            ),
            shape = RoundedCornerShape(12.dp),
        )
        if (overLimit) {
            Spacer(Modifier.height(6.dp))
            Text(
                "라이센스 최대 ${maxAllowed}개까지 가능",
                fontSize = 11.sp, color = danger,
            )
        }
    }
    Spacer(Modifier.height(20.dp))
    Button(
        onClick = onStart,
        enabled = !overLimit,
        modifier = Modifier.fillMaxWidth().height(54.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = accent, contentColor = Color.White,
            disabledContainerColor = borderCol, disabledContentColor = textSub,
        ),
        shape = RoundedCornerShape(12.dp),
    ) {
        Text("시작", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RunView(s: TokenGenerator.State, onStop: () -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${s.done} / ${s.target}", fontSize = 15.sp, color = textMain, fontWeight = FontWeight.Medium)
            Text("${s.pct}%", fontSize = 15.sp, color = accent, fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(12.dp))
        LinearProgressIndicator(
            progress = s.pct / 100f,
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = accent, trackColor = borderCol,
        )
    }
    Spacer(Modifier.height(24.dp))
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        KvRow("성공", "${s.ok}", success)
        KvRow("실패", "${s.fail}", danger)
        KvRow("속도", "%.1f 개/초".format(s.rate), textMain)
        KvRow("경과", "${s.elapsedMs / 1000}초", textMain)
    }
    Spacer(Modifier.height(20.dp))
    TokenLogStream(s.logs)
    Spacer(Modifier.height(16.dp))
    OutlinedButton(
        onClick = onStop,
        modifier = Modifier.fillMaxWidth().height(48.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderCol),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = textMain),
        shape = RoundedCornerShape(12.dp),
    ) { Text("중지", fontSize = 14.sp) }
}

@Composable
private fun DoneView(state: TokenGenerator.State?, ctx: Context, onAgain: () -> Unit) {
    val s = state ?: TokenGenerator.State()
    val scope = rememberCoroutineScope()
    var format by remember { mutableStateOf(ExportFormat.TOKEN_ONLY) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        KvRow("생성 완료", "${s.ok} / ${s.target}", success)
        KvRow("실패", "${s.fail}", danger)
        KvRow("소요 시간", "${s.elapsedMs / 1000}초", textMain)
        KvRow("평균 속도", "%.2f 개/초".format(s.rate), textMain)
    }

    Spacer(Modifier.height(24.dp))
    Text("내보내기 형식", fontSize = 13.sp, color = textSub)
    Spacer(Modifier.height(8.dp))

    // 포맷 선택 - 3개 칩
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ExportFormat.values().forEach { f ->
            val sel = f == format
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (sel) accent else card)
                    .border(1.dp, if (sel) accent else borderCol, RoundedCornerShape(10.dp))
                    .clickable { format = f }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        f.label,
                        fontSize = 12.sp,
                        color = if (sel) Color.White else textMain,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        f.desc,
                        fontSize = 9.sp,
                        color = if (sel) Color.White.copy(alpha = 0.7f) else textSub,
                        fontFamily = FontFamily.Monospace,
                    )
                }
            }
        }
    }

    Spacer(Modifier.height(20.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(
            onClick = {
                scope.launch { copyTokens(ctx, format) }
            },
            modifier = Modifier.weight(1f).height(48.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, borderCol),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = textMain),
            shape = RoundedCornerShape(10.dp),
        ) { Text("복사", fontSize = 14.sp) }
        OutlinedButton(
            onClick = {
                scope.launch { exportTxt(ctx, format) }
            },
            modifier = Modifier.weight(1f).height(48.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, borderCol),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = textMain),
            shape = RoundedCornerShape(10.dp),
        ) { Text("txt 공유", fontSize = 14.sp) }
    }

    Spacer(Modifier.height(10.dp))

    Button(
        onClick = onAgain,
        modifier = Modifier.fillMaxWidth().height(48.dp),
        colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.White),
        shape = RoundedCornerShape(10.dp),
    ) { Text("다시 생성", fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
}

// ─ 터미널 로그 스트림 ─
@Composable
private fun TokenLogStream(logs: List<TokenGenerator.TokenLog>) {
    val fmt = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val listState = rememberLazyListState()
    LaunchedEffect(logs.firstOrNull()?.ts) {
        if (logs.isNotEmpty()) listState.animateScrollToItem(0)
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(termBg)
            .padding(14.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Row {
                Box(Modifier.size(7.dp).clip(RoundedCornerShape(50)).background(Color(0xFFFF5F57)))
                Spacer(Modifier.width(5.dp))
                Box(Modifier.size(7.dp).clip(RoundedCornerShape(50)).background(Color(0xFFFEBC2E)))
                Spacer(Modifier.width(5.dp))
                Box(Modifier.size(7.dp).clip(RoundedCornerShape(50)).background(Color(0xFF28C840)))
            }
            Spacer(Modifier.width(10.dp))
            Text("tokens.stream", fontSize = 10.sp, color = termTime, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.weight(1f))
            Box(Modifier.size(6.dp).clip(RoundedCornerShape(50)).background(termTok))
            Spacer(Modifier.width(5.dp))
            Text("LIVE", fontSize = 9.sp, color = termTok, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(
            modifier = Modifier.fillMaxWidth().height(180.dp),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(3.dp),
        ) {
            items(logs, key = { it.ts }) { log ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(fmt.format(Date(log.ts)), fontSize = 10.sp, color = termTime, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.width(7.dp))
                    Text(if (log.verified) "v" else "·", fontSize = 10.sp,
                        color = if (log.verified) termTok else termHash,
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(3.dp))
                    Text(if (log.humanized) "h" else "·", fontSize = 10.sp,
                        color = if (log.humanized) termTok else termHash,
                        fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Text(maskToken(log.token), fontSize = 11.sp, color = termTok, fontFamily = FontFamily.Monospace)
                }
            }
            if (logs.isEmpty()) {
                item { Text("waiting...", fontSize = 11.sp, color = termHash, fontFamily = FontFamily.Monospace) }
            }
        }
    }
}

// ═════════════════════════════════════════════════════════════
//  [탭2] 토큰 체커
// ═════════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CheckScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var checker by remember { mutableStateOf<TokenChecker?>(null) }
    val s = checker?.state?.collectAsState()?.value
    var done by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(horizontal = adaptivePaddingH(), vertical = 28.dp).widthIn(max = adaptiveMaxWidth())) {
        TopBar()
        Spacer(Modifier.height(24.dp))
        Text("토큰 입력 (한 줄에 하나)", fontSize = 13.sp, color = textSub)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier.fillMaxWidth().height(160.dp),
            placeholder = { Text("토큰 또는 이메일:비번:토큰 포맷", color = textSub) },
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = accent, unfocusedBorderColor = borderCol, cursorColor = accent,
                focusedContainerColor = card, unfocusedContainerColor = card,
            ),
            shape = RoundedCornerShape(12.dp),
        )
        Spacer(Modifier.height(16.dp))

        if (s == null || !s.running) {
            Button(
                onClick = {
                    val tokens = parseTokenInput(input)
                    if (tokens.isEmpty()) return@Button
                    done = false
                    val c = TokenChecker(tokens, proxies = listOf(K_PROXY), parallel = 10)
                    checker = c
                    scope.launch { c.run(); done = true }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.White),
                shape = RoundedCornerShape(12.dp),
            ) { Text("체크 시작", fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
        }

        if (s != null) {
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${s.done} / ${s.total}", fontSize = 14.sp, color = textMain)
                Text("${s.pct}%", fontSize = 14.sp, color = accent, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = s.pct / 100f,
                modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
                color = accent, trackColor = borderCol,
            )
            Spacer(Modifier.height(16.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                KvRow("valid", "${s.valid}", success)
                KvRow("locked", "${s.locked}", Color(0xFFF59E0B))
                KvRow("invalid", "${s.invalid}", danger)
                KvRow("error", "${s.error}", textSub)
                KvRow("nitro", "${s.nitroCount}", Color(0xFF9333EA))
            }
            if (!s.running && done && s.valid > 0) {
                Spacer(Modifier.height(16.dp))
                OutlinedButton(
                    onClick = {
                        val valid = s.results.filter { it.status == "valid" }.joinToString("\n") { it.token }
                        val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("valid tokens", valid))
                        Toast.makeText(ctx, "valid ${s.valid}개 복사됨", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, borderCol),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = textMain),
                    shape = RoundedCornerShape(10.dp),
                ) { Text("유효 토큰만 복사", fontSize = 14.sp) }
            }
        }
    }
}

// ═════════════════════════════════════════════════════════════
//  [탭3] 토큰 레이더
// ═════════════════════════════════════════════════════════════
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RaidScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var tokensRaw by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    var payload by remember { mutableStateOf("") }
    var raidType by remember { mutableStateOf(RaidType.JOIN) }
    var raider by remember { mutableStateOf<TokenRaider?>(null) }
    val s = raider?.state?.collectAsState()?.value

    Column(Modifier.fillMaxSize().padding(horizontal = adaptivePaddingH(), vertical = 28.dp).widthIn(max = adaptiveMaxWidth())) {
        TopBar()
        Spacer(Modifier.height(20.dp))

        // 공격 유형 선택
        Text("공격 유형", fontSize = 13.sp, color = textSub)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            RaidType.values().take(3).forEach { t ->
                val sel = t == raidType
                Box(
                    Modifier.weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (sel) accent else card)
                        .border(1.dp, if (sel) accent else borderCol, RoundedCornerShape(8.dp))
                        .clickable { raidType = t }
                        .padding(vertical = 9.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(t.label, fontSize = 11.sp, color = if (sel) Color.White else textMain, fontWeight = FontWeight.Medium)
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            RaidType.values().drop(3).forEach { t ->
                val sel = t == raidType
                Box(
                    Modifier.weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (sel) accent else card)
                        .border(1.dp, if (sel) accent else borderCol, RoundedCornerShape(8.dp))
                        .clickable { raidType = t }
                        .padding(vertical = 9.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(t.label, fontSize = 11.sp, color = if (sel) Color.White else textMain, fontWeight = FontWeight.Medium)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // 타겟 입력
        val targetLabel = when (raidType) {
            RaidType.JOIN -> "초대 코드"
            RaidType.DM_SPAM -> "유저 ID"
            RaidType.REACT -> "채널ID:메시지ID"
            RaidType.CH_SPAM, RaidType.MENTION -> "채널 ID"
        }
        OutlinedTextField(
            value = target, onValueChange = { target = it },
            label = { Text(targetLabel, fontSize = 12.sp) },
            modifier = Modifier.fillMaxWidth(), singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, fontFamily = FontFamily.Monospace),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = accent, unfocusedBorderColor = borderCol, cursorColor = accent,
                focusedContainerColor = card, unfocusedContainerColor = card,
            ),
            shape = RoundedCornerShape(10.dp),
        )

        if (raidType != RaidType.JOIN) {
            Spacer(Modifier.height(10.dp))
            val plLabel = if (raidType == RaidType.REACT) "이모지" else "메시지 내용"
            OutlinedTextField(
                value = payload, onValueChange = { payload = it },
                label = { Text(plLabel, fontSize = 12.sp) },
                modifier = Modifier.fillMaxWidth(), singleLine = raidType == RaidType.REACT,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = accent, unfocusedBorderColor = borderCol, cursorColor = accent,
                    focusedContainerColor = card, unfocusedContainerColor = card,
                ),
                shape = RoundedCornerShape(10.dp),
            )
        }

        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = tokensRaw, onValueChange = { tokensRaw = it },
            label = { Text("토큰 (한 줄에 하나)", fontSize = 12.sp) },
            modifier = Modifier.fillMaxWidth().height(120.dp),
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = accent, unfocusedBorderColor = borderCol, cursorColor = accent,
                focusedContainerColor = card, unfocusedContainerColor = card,
            ),
            shape = RoundedCornerShape(10.dp),
        )

        Spacer(Modifier.height(16.dp))

        if (s == null || !s.running) {
            Button(
                onClick = {
                    val tokens = parseTokenInput(tokensRaw)
                    if (tokens.isEmpty() || target.isBlank()) return@Button
                    val r = TokenRaider(
                        tokens = tokens, type = raidType,
                        target = target, payload = payload,
                        proxies = listOf(K_PROXY),
                    )
                    raider = r
                    scope.launch { r.run() }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = danger, contentColor = Color.White),
                shape = RoundedCornerShape(12.dp),
            ) { Text("공격 시작", fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
        }

        if (s != null) {
            Spacer(Modifier.height(14.dp))
            LinearProgressIndicator(
                progress = s.pct / 100f,
                modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
                color = danger, trackColor = borderCol,
            )
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("성공 ${s.success}", fontSize = 13.sp, color = success, fontWeight = FontWeight.SemiBold)
                Text("실패 ${s.failed}", fontSize = 13.sp, color = danger, fontWeight = FontWeight.SemiBold)
                Text("${s.done}/${s.total}", fontSize = 13.sp, color = textSub, fontFamily = FontFamily.Monospace)
            }
            Spacer(Modifier.height(10.dp))
            // 간단 터미널
            Box(
                Modifier.fillMaxWidth().height(130.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(termBg)
                    .padding(10.dp),
            ) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    items(s.lastLog) { line ->
                        val color = if (line.startsWith("+")) termTok else Color(0xFFF87171)
                        Text(line, fontSize = 10.sp, color = color, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

// ═════════════════════════════════════════════════════════════
//  공통 조각
// ═════════════════════════════════════════════════════════════
@Composable
private fun KvRow(label: String, value: String, valueColor: Color) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 15.sp, color = textSub)
        Text(value, fontSize = 16.sp, color = valueColor, fontWeight = FontWeight.SemiBold)
    }
}

/** 토큰 마스킹 - 앞 20자 + ... + 뒤 6자. */
private fun maskToken(token: String): String {
    if (token.length <= 32) return token
    return token.take(20) + "..." + token.takeLast(6)
}

/** 입력 파싱 - 각 줄에서 토큰만 추출 (email:pass:token / token 둘 다 처리). */
private fun parseTokenInput(raw: String): List<String> {
    return raw.lines().mapNotNull { line ->
        val t = line.trim()
        if (t.isEmpty() || t.startsWith("#")) return@mapNotNull null
        // email:pass:token 포맷이면 마지막 부분이 토큰
        if (":" in t && t.count { it == ':' } >= 2) {
            val parts = t.split(":")
            parts.last().trim().ifEmpty { null }
        } else t
    }
}

// ─ 파일 저장 & 포맷별 복사/공유 ─
private fun saveTokens(ctx: Context, tokens: List<String>) {
    try { File(ctx.filesDir, "tokens.txt").writeText(tokens.joinToString("\n")) } catch (_: Exception) {}
}

/** 지정 포맷으로 조립. 현재 generated_tokens.txt 가 email:pass:token 포맷으로 저장되어 있음. */
private fun formatTokens(ctx: Context, format: ExportFormat): String {
    val raw = try { File(ctx.filesDir, "tokens.txt").readText() } catch (_: Exception) { return "" }
    return raw.lines().mapNotNull { line ->
        val t = line.trim()
        if (t.isEmpty()) return@mapNotNull null
        // register 이후 저장된 토큰 - 단순 토큰 문자열만
        // 다른 포맷은 레거시이거나 수동 입력일 때. 기본은 토큰만.
        when (format) {
            ExportFormat.TOKEN_ONLY -> t
            ExportFormat.EMAIL_PASS -> {
                // 토큰만 있는 경우 skip, email:pass 포맷인 경우만 변환
                if (":" in t) t.split(":").take(2).joinToString(":") else null
            }
            ExportFormat.FULL -> {
                if (":" in t) t else null
            }
        }
    }.joinToString("\n")
}

private fun copyTokens(ctx: Context, format: ExportFormat) {
    val content = formatTokens(ctx, format)
    if (content.isEmpty()) {
        Toast.makeText(ctx, "저장된 토큰 없음", Toast.LENGTH_SHORT).show(); return
    }
    val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("leviathanic tokens", content))
    Toast.makeText(ctx, "클립보드에 복사됨", Toast.LENGTH_SHORT).show()
}

private fun exportTxt(ctx: Context, format: ExportFormat) {
    val content = formatTokens(ctx, format)
    if (content.isEmpty()) return
    try {
        val f = File(ctx.filesDir, "export_${format.name.lowercase()}.txt")
        f.writeText(content)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fp", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, null))
    } catch (_: Exception) {}
}
