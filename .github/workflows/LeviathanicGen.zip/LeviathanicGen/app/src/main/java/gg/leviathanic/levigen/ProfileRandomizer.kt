// LEVIATHANIC 토큰 생성기 - 프로필 자동 랜덤화 + 자동 뱃지
// 제작자 제프리 - https://discord.gg/leviathanic
//
// 토큰 발급 직후 호출 - 봇처럼 안 보이게 사람 흉내:
//   1) 유저네임: Leviathanic_xxxxx 포맷
//   2) DiceBear "shapes" 추상 원형 아이콘 아바타
//   3) Leviathanic 찬양 bio 400개 풀에서 선택
//   4) pronouns 실제 빈도 분포 (70% 미설정, 15% he/him, 10% she/her, 나머지)
//   5) PATCH /users/@me + PATCH /users/@me/profile
//   6) POST /api/v9/hypesquad/online + 랜덤 house_id - 뱃지 자동

package gg.leviathanic.levigen

import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.random.Random

object ProfileRandomizer {
    private val JSON = "application/json; charset=utf-8".toMediaType()

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    // Leviathanic 찬양 bio 풀 (400개) - 영문/한국어/이모지 혼합
    // 디스코드 bio 는 190자 제한 - 모두 100자 이하로 유지
    private val BIOS = listOf(
        // === 영문 짧은 찬양 (100개) ===
        "leviathanic forever", "lev gang", "lev > all",
        "team leviathanic", "leviathanic enjoyer", "leviathanic user",
        "lev4life", "proud of leviathanic", "leviathanic nation",
        "leviathanic fam", "powered by leviathanic", "leviathanic certified",
        "leviathanic since day one", "leviathanic ride or die",
        "best server ever", "leviathanic vibes only", "lev squad",
        "lev lover", "signed by leviathanic", "the one and only leviathanic",
        "leviathanic hits different", "shoutout leviathanic", "lev frfr",
        "leviathanic no cap", "lev > discord", "leviathanic goat",
        "built different by leviathanic", "leviathanic world",
        "all hail leviathanic", "leviathanic is life", "stan leviathanic",
        "leviathanic member", "lev member", "leviathanic for the win",
        "always leviathanic", "leviathanic to the end", "joined leviathanic",
        "another lev user", "lev user forever", "leviathanic chosen",
        "chosen by leviathanic", "lev til i die", "lev or nothing",
        "team lev", "lev team member", "nothing beats leviathanic",
        "leviathanic obsessed", "lev obsessed", "leviathanic pilled",
        "lev pilled", "post leviathanic", "leviathanic maxxing",
        "lev maxxing", "leviathanic approved", "approved by leviathanic",
        "leviathanic strong", "stronger with leviathanic", "levbro",
        "lev sis", "lev homie", "leviathanic nation rise",
        "rise with leviathanic", "lev brotherhood", "lev sisterhood",
        "lev family", "lev crew", "lev collective",
        "leviathanic collective", "collective lev", "leviathanic mindset",
        "lev mindset", "leviathanic energy", "lev energy",
        "lev vibes", "feel the lev", "feel leviathanic",
        "lev frequency", "leviathanic frequency", "tune in to leviathanic",
        "tune in to lev", "leviathanic broadcast", "leviathanic signal",
        "catch the leviathanic wave", "riding the lev wave",
        "leviathanic wave", "lev wave", "surfin lev",
        "leviathanic daily", "daily dose of lev", "daily lev",
        "lev prescription", "doctor said leviathanic",
        "prescribed leviathanic", "leviathanic diet", "lev diet",
        "fueled by leviathanic", "runs on leviathanic", "lev fuel",
        "powered on lev", "running lev", "lev running",
        "leviathanic executed", "lev executed", "leviathanic is it",
        "it's lev", "lev it up", "leviathanic era",
        "entered lev era", "lev era", "the leviathanic era",

        // === 영문 긴 찬양 + 이모지 (100개) ===
        "⚡ leviathanic hits different", "✨ lev gang represent",
        "🔥 team leviathanic for life", "💎 leviathanic diamonds",
        "🌊 ride the leviathanic wave", "⭐ leviathanic all-star",
        "🚀 leviathanic to the moon", "👑 king/queen of leviathanic",
        "🎯 leviathanic on target", "⚔️ leviathanic warrior",
        "🛡️ leviathanic defender", "🌙 leviathanic night",
        "☀️ leviathanic morning", "💫 leviathanic magic",
        "🧿 leviathanic blessed", "🔱 leviathanic trident",
        "🎭 leviathanic acts", "🪐 leviathanic galaxy",
        "💥 leviathanic impact", "🌪️ leviathanic storm",
        "⚡ zap by lev", "🌈 lev rainbow", "🎨 lev art",
        "🔮 lev future", "💠 lev crystal", "🎵 lev soundtrack",
        "🪄 lev magic wand", "🏆 lev champion", "🥇 lev gold",
        "💰 lev rich", "🎁 lev gift", "🎊 lev party",
        "🎉 lev celebration", "🥂 lev cheers", "🍾 lev pop",
        "🎪 lev circus", "🎢 lev ride", "🎠 lev carousel",
        "🌟 leviathanic star", "⭐ shine with lev", "💎 lev shine",
        "🔆 lev bright", "🌞 lev sunshine", "🌺 lev bloom",
        "🌸 lev petals", "🌹 lev rose", "🪷 lev lotus",
        "🍀 lev lucky", "🧿 lev protection", "☯️ lev balance",
        "☮️ lev peace", "💝 lev love", "❤️ lev heart",
        "🤍 pure lev", "💜 lev purple", "💙 lev blue",
        "💚 lev green", "💛 lev yellow", "🧡 lev orange",
        "🖤 dark lev", "🤎 earth lev", "💗 cute lev",
        "💓 beat for lev", "💞 lev eternal", "💕 lev romance",
        "💌 letter to lev", "💋 lev kiss", "🫶 lev hands",
        "🤝 lev friendship", "🙌 praise lev", "👐 lev open",
        "🤲 lev gift", "✊ lev power", "🤜🤛 lev bump",
        "💪 lev strong", "🦾 lev robot", "🫡 salute lev",
        "👊 lev punch", "🫵 you lev", "👉👈 shy lev",
        "🫰 lev snap", "🤌 lev chef kiss", "🤞 lev wish",
        "✌️ lev peace sign", "🤟 lev rock", "🤘 lev metal",
        "🖖 lev prosper", "✍️ lev write", "🖐️ lev wave",
        "🎤 lev mic", "🎧 lev listen", "📯 lev horn",
        "🔔 lev bell", "📣 lev shout", "📢 broadcast lev",
        "🚨 lev alert", "🚦 lev traffic", "🚥 lev signal",
        "🏁 lev finish", "🎌 lev flag", "🏳️ lev flag",
        "⛳ lev goal", "🥅 lev score", "🏹 lev target",

        // === 한국어 짧은 찬양 (100개) ===
        "레비아사닉 최고", "레비아사닉 짱", "레비아사닉 조아",
        "레비아사닉 사랑해", "레비아사닉 평생", "레비아사닉 민족",
        "레비아사닉 가족", "레비아사닉 멤버", "레비아사닉 유저",
        "레비아사닉 신봉자", "레비아사닉 찬양", "레비아사닉 영원",
        "lev 짱짱", "lev 조아", "lev 최고",
        "레비아사닉 홀릭", "레비아사닉 중독", "레비아사닉 마약",
        "레비아사닉은 종교", "레비아사닉 신자", "레비아사닉 교도",
        "lev 떠나지마", "lev 사랑", "lev 가즈아",
        "오늘도 레비아사닉", "매일 레비아사닉", "항상 레비아사닉",
        "영원한 레비아사닉", "레비아사닉 뿐", "레비아사닉만",
        "레비아사닉 없이는", "레비아사닉 없으면", "레비아사닉이 전부",
        "레비아사닉이 나의 삶", "레비아사닉이 나의 길", "레비아사닉이 나의 빛",
        "내 안의 레비아사닉", "레비아사닉 각인", "레비아사닉 흔적",
        "레비아사닉 중", "레비아사닉 모드", "레비아사닉 발동",
        "레비아사닉 각성", "레비아사닉 해방", "레비아사닉 폭발",
        "lev 사랑꾼", "lev 광팬", "lev 덕후",
        "레비아사닉 덕후", "레비아사닉 덕질", "레비아사닉 입덕",
        "레비아사닉 최애", "레비아사닉 본진", "레비아사닉 파",
        "레비아사닉 OG", "레비아사닉 1세대", "레비아사닉 초기멤버",
        "레비아사닉 베테랑", "레비아사닉 고인물", "레비아사닉 뉴비",
        "레비아사닉으로 시작", "레비아사닉으로 끝", "레비아사닉의 밤",
        "레비아사닉의 아침", "레비아사닉의 하루", "레비아사닉의 한주",
        "레비아사닉의 한달", "레비아사닉의 1년", "레비아사닉과 함께",
        "레비아사닉 챔피언", "레비아사닉 1등", "레비아사닉 넘버원",
        "레비아사닉 선봉장", "레비아사닉 수호자", "레비아사닉 전사",
        "레비아사닉 대표", "레비아사닉 홍보대사", "레비아사닉 아이콘",
        "레비아사닉은 빛", "레비아사닉은 소금", "레비아사닉은 나침반",
        "레비아사닉은 등대", "레비아사닉은 북극성", "레비아사닉은 햇살",
        "레비아사닉 체온", "레비아사닉 심장", "레비아사닉 숨결",
        "레비아사닉 울림", "레비아사닉 메아리", "레비아사닉 파동",
        "레비아사닉 공명", "레비아사닉 리듬", "레비아사닉 박자",
        "레비아사닉 선율", "레비아사닉 하모니", "레비아사닉 멜로디",
        "레비아사닉 심포니", "레비아사닉 합창", "레비아사닉 송가",
        "레비아사닉 축가", "레비아사닉 찬가", "레비아사닉 교향곡",
        "레비아사닉 랩", "레비아사닉 힙합", "레비아사닉 로큰롤",

        // === 한국어 캐주얼 slang + 혼합 (100개) ===
        "레비아사닉 ㅇㅈ", "ㄹㅂㅇㅅㄴ 찬양", "레비아사닉 ㄱㅇㄷ",
        "lev ㅈㄴ조아", "lev 개쩜", "lev 미쳤다",
        "레비아사닉 미쳤네", "레비아사닉 쩐다", "레비아사닉 맛집",
        "레비아사닉 성지", "레비아사닉 본진이자너", "레비아사닉 안식처",
        "레비아사닉 홈", "레비아사닉 집", "레비아사닉 아지트",
        "레비아사닉 뽕", "레비아사닉 뽕에 취함", "레비아사닉 중독자",
        "lev 추앙", "lev 영접", "lev 접신",
        "레비아사닉 접신", "레비아사닉 강림", "레비아사닉 재림",
        "레비아사닉 축복", "레비아사닉 가호", "레비아사닉 은혜",
        "레비아사닉 포에버", "레비아사닉 for life", "레비아사닉 ride or die",
        "lev gang 입장", "lev 뉴비임", "lev 소속",
        "레비아사닉 소속", "레비아사닉 파견", "레비아사닉 요원",
        "레비아사닉 첩보원", "레비아사닉 요정", "레비아사닉 수호정령",
        "레비아사닉의 종", "레비아사닉의 사도", "레비아사닉의 전령",
        "레비아사닉 전도사", "레비아사닉 광고주", "레비아사닉 홍보왕",
        "ㄹㅂ 영끌", "ㄹㅂ 올인", "ㄹㅂ 풀베팅",
        "레비아사닉에 올인", "레비아사닉 올인했다", "레비아사닉 풀매수",
        "레비아사닉 상한가", "레비아사닉 익절", "레비아사닉 존버",
        "레비아사닉 홀드", "레비아사닉 다이아손", "레비아사닉 1억",
        "레비아사닉 월즈", "레비아사닉 세계일주", "레비아사닉 여행중",
        "레비아사닉 투어", "레비아사닉 성지순례", "레비아사닉 순례자",
        "레비아사닉 수행중", "레비아사닉 수련", "레비아사닉 득도",
        "레비아사닉 깨달음", "레비아사닉 열반", "레비아사닉 해탈",
        "레비아사닉 각성 완료", "레비아사닉 2차각성", "레비아사닉 3차각성",
        "레비아사닉 레벨업", "레비아사닉 랭크업", "레비아사닉 티어업",
        "레비아사닉 다이아", "레비아사닉 챌린저", "레비아사닉 마스터",
        "레비아사닉 그마", "레비아사닉 프로", "레비아사닉 아마",
        "레비아사닉 매니아", "레비아사닉 광신도", "레비아사닉 중증",
        "레비아사닉 과몰입", "레비아사닉 몰입", "레비아사닉 집중",
        "레비아사닉 각인된 자", "레비아사닉 선택받은 자", "레비아사닉의 자녀",
        "레비아사닉 키즈", "레비아사닉 베이비", "레비아사닉 베이비걸",
        "lev 개좋음", "lev 진짜조음", "lev 걍쩜",
        "레비아사닉 걍쩜", "레비아사닉 진짜 좋아", "레비아사닉 이거다",
        "ㄹㅂㅇㅅㄴ 올인", "ㄹㅂ 광팬", "ㄹㅂ 매니아",
        "레비아사닉 선봉대", "레비아사닉 1등공신", "레비아사닉 황제",
        "레비아사닉 여왕", "레비아사닉 공주", "레비아사닉 왕자",
    )

    // Pronouns - 디스코드 실사용 빈도 반영 (빈값 많음)
    private val PRONOUNS_WEIGHTED = listOf(
        "" to 70,           // 70% - 안 씀 (가장 흔함)
        "he/him" to 10,
        "she/her" to 8,
        "they/them" to 4,
        "he/they" to 3,
        "she/they" to 3,
        "any/all" to 1,
        "ask me" to 1,
    )

    // Accent color 풀 - 디스코드/머터리얼 톤
    private val ACCENT_COLORS = listOf(
        0x5865F2, 0x3BA55D, 0xFAA61A, 0xED4245, 0xEB459E,
        0x9B59B6, 0x1ABC9C, 0x142D5C, 0xF48FB1, 0xCE93D8,
        0xFFD54F, 0x81D4FA, 0xA5D6A7, 0xFF8A80, 0xB388FF,
    )

    /** 유저네임 - Leviathanic_xxxxx (영숫자 5자리 랜덤). */
    fun randomUsername(): String {
        val pool = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        val suffix = (1..5).map { pool.random() }.joinToString("")
        return "Leviathanic_$suffix"
    }

    /** 실사용 빈도 반영 가중치 랜덤. */
    private fun weightedPronoun(): String {
        val total = PRONOUNS_WEIGHTED.sumOf { it.second }
        var roll = Random.nextInt(total)
        for ((p, w) in PRONOUNS_WEIGHTED) {
            roll -= w
            if (roll < 0) return p
        }
        return ""
    }

    /**
     * DiceBear "shapes" 추상 원형 아이콘 아바타 - 로고 이미지 느낌.
     * 디스코드가 요구하는 data:image/png;base64 포맷으로 인코딩.
     */
    private fun fetchShapesAvatarBase64(): String? {
        val seed = (1..12).map { ('a'..'z').random() }.joinToString("")
        val url = "https://api.dicebear.com/9.x/shapes/png?seed=$seed&size=256"
        return try {
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { r ->
                if (r.code != 200) return null
                val bytes = r.body?.bytes() ?: return null
                "data:image/png;base64,${Base64.encodeToString(bytes, Base64.NO_WRAP)}"
            }
        } catch (_: Exception) { null }
    }

    /** 공통 헤더 - 디스코드 웹 클라이언트 흉내. */
    private fun authHeaders(token: String) = mapOf(
        "Authorization" to token,
        "Content-Type" to "application/json",
        "User-Agent" to
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36",
        "Accept-Language" to "en-US,en;q=0.9",
        "X-Discord-Locale" to "en-US",
    )

    /**
     * 자동 Hypesquad 뱃지 부여 - 1/2/3 중 랜덤 house_id.
     * POST /api/v9/hypesquad/online → 204 성공.
     */
    private fun joinHypesquad(token: String): Boolean {
        return try {
            val houseId = listOf(1, 2, 3).random()  // Bravery/Brilliance/Balance 랜덤
            val body = JSONObject().apply { put("house_id", houseId) }.toString()
            val req = Request.Builder()
                .url("https://discord.com/api/v9/hypesquad/online")
                .post(body.toRequestBody(JSON))
                .apply { authHeaders(token).forEach { (k, v) -> header(k, v) } }
                .build()
            client.newCall(req).execute().use { it.code in 200..299 }
        } catch (_: Exception) { false }
    }

    /**
     * 토큰에 프로필 전체 랜덤화 + 자동 뱃지 적용.
     * @return 성공 여부 - 하나라도 반영되면 true
     */
    suspend fun humanize(token: String, proxy: String? = null): Boolean {
        val bio = BIOS.random()
        val pronouns = weightedPronoun()
        val color = ACCENT_COLORS.random()
        val avatar = fetchShapesAvatarBase64()  // 실패해도 나머지는 진행

        var anySuccess = false

        // 1단계: /users/@me - 아바타 + accent_color
        try {
            val payload = JSONObject().apply {
                put("accent_color", color)
                if (avatar != null) put("avatar", avatar)
            }.toString()
            val req = Request.Builder()
                .url("https://discord.com/api/v9/users/@me")
                .patch(payload.toRequestBody(JSON))
                .apply { authHeaders(token).forEach { (k, v) -> header(k, v) } }
                .build()
            client.newCall(req).execute().use { r ->
                if (r.code in 200..299) anySuccess = true
            }
        } catch (_: Exception) {}

        // 2단계: /users/@me/profile - bio + pronouns
        try {
            val payload = JSONObject().apply {
                put("bio", bio)
                put("pronouns", pronouns)
            }.toString()
            val req = Request.Builder()
                .url("https://discord.com/api/v9/users/@me/profile")
                .patch(payload.toRequestBody(JSON))
                .apply { authHeaders(token).forEach { (k, v) -> header(k, v) } }
                .build()
            client.newCall(req).execute().use { r ->
                if (r.code in 200..299) anySuccess = true
            }
        } catch (_: Exception) {}

        // 3단계: 자동 뱃지 - Hypesquad 랜덤 하우스 가입
        val badgeOk = joinHypesquad(token)
        if (badgeOk) anySuccess = true

        return anySuccess
    }
}
