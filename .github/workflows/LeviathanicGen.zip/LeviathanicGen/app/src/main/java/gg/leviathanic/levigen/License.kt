// LEVIATHANIC 토큰 생성기 - 라이센스 시스템
// 제작자 제프리 - https://discord.gg/leviathanic
//
// 오프라인 HMAC 기반 라이센스 검증.
// 라이센스 포맷: base64url(payload) + "." + base64url(HMAC-SHA256(payload))
// payload JSON: { "u": user, "e": expiresMs, "m": maxTokens }
//
// 관리자가 발급: 같은 HMAC 키로 payload 를 서명 → 라이센스 문자열 생성
// 앱이 검증: 서명 재계산해서 일치하면 유효, 만료 체크

package gg.leviathanic.levigen

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object License {
    // 서명용 HMAC 비밀키 - 관리자패널과 앱이 공유하는 내장 키
    // (오프라인 라이센스의 한계 - APK 디컴파일하면 노출됨)
    private const val HMAC_KEY = "Lev_sIgN_K3y_2026_Jeffrey_Kcg505050g"

    // 관리자 패널 접근 비밀번호
    const val ADMIN_SECRET = "Kcg505050g!"

    // 저장된 라이센스 조회용 SharedPreferences 키
    private const val PREF_NAME = "leviathanic_license"
    private const val KEY_LICENSE = "license"

    /** 라이센스 검증 결과. */
    data class Info(
        val valid: Boolean,
        val user: String = "",
        val expiresMs: Long = 0,
        val maxTokens: Int = 0,
        val reason: String = "",
    ) {
        val daysLeft: Long get() =
            ((expiresMs - System.currentTimeMillis()) / 86_400_000L).coerceAtLeast(0L)
    }

    /** payload JSON 을 HMAC-SHA256 으로 서명. */
    private fun sign(payload: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(HMAC_KEY.toByteArray(), "HmacSHA256"))
        val sig = mac.doFinal(payload.toByteArray())
        return Base64.encodeToString(sig, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }

    /**
     * 라이센스 발급 - 관리자 전용.
     * @param user 유저 이름/식별자
     * @param days 유효 기간 (일)
     * @param maxTokens 최대 생성 가능 토큰 수 (0 = 무제한)
     * @return 라이센스 문자열
     */
    fun issue(user: String, days: Int, maxTokens: Int): String {
        val expiresMs = System.currentTimeMillis() + days * 86_400_000L
        val payload = JSONObject().apply {
            put("u", user)
            put("e", expiresMs)
            put("m", maxTokens)
        }.toString()
        val payloadB64 = Base64.encodeToString(
            payload.toByteArray(),
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        )
        val signature = sign(payload)
        return "$payloadB64.$signature"
    }

    /** 라이센스 문자열 검증. */
    fun verify(licenseStr: String): Info {
        val str = licenseStr.trim()
        if (str.isEmpty()) return Info(false, reason = "empty")

        val parts = str.split(".")
        if (parts.size != 2) return Info(false, reason = "invalid format")

        return try {
            val payloadBytes = Base64.decode(parts[0], Base64.URL_SAFE)
            val payload = String(payloadBytes)
            val expectedSig = sign(payload)
            if (expectedSig != parts[1]) {
                return Info(false, reason = "signature mismatch")
            }
            val j = JSONObject(payload)
            val expires = j.optLong("e", 0)
            if (System.currentTimeMillis() > expires) {
                return Info(false, reason = "expired")
            }
            Info(
                valid = true,
                user = j.optString("u"),
                expiresMs = expires,
                maxTokens = j.optInt("m", 0),
            )
        } catch (e: Exception) {
            Info(false, reason = e.message ?: "parse error")
        }
    }

    /** 저장된 라이센스 로드. */
    fun load(ctx: Context): String {
        val prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_LICENSE, "") ?: ""
    }

    /** 라이센스 저장. */
    fun save(ctx: Context, licenseStr: String) {
        val prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_LICENSE, licenseStr).apply()
    }

    /** 저장된 라이센스 삭제 (로그아웃). */
    fun clear(ctx: Context) {
        val prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_LICENSE).apply()
    }
}
