// LEVIATHANIC 토큰 생성기 - 토큰 체커 모듈
// 제작자 제프리 - https://discord.gg/leviathanic
//
// 참고:
//   - V4NSH4J/FAST-discord-token-checker (Go 기반 체커 패턴)
//   - Zetrium 토큰 체커 (/users/@me/settings 응답 분류)
//
// 체크 흐름:
//   GET /api/v9/users/@me/settings
//     200 → valid
//     응답에 "verify your account" → locked
//     401 → invalid
//
// 추가 조회 (valid 시):
//   /users/@me - 니트로/이메일/인증상태
//   /users/@me/billing/payment-sources - 결제수단 수
//   /users/@me/billing/subscriptions - 니트로 구독 수

package gg.leviathanic.levigen

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class TokenChecker(
    private val tokens: List<String>,
    private val proxies: List<String> = emptyList(),
    private val parallel: Int = 10,
) {
    /** 토큰 1개의 체크 결과. */
    data class Result(
        val token: String,
        val status: String,      // valid / locked / invalid / timeout / error
        val username: String? = null,
        val id: String? = null,
        val email: String? = null,
        val phone: String? = null,
        val mfa: Boolean = false,
        val nitro: Int = 0,        // 0=없음, 1=classic, 2=full, 3=basic
        val verified: Boolean = false,
    )

    /** 체크 진행 상태. */
    data class State(
        val done: Int = 0,
        val total: Int = 0,
        val valid: Int = 0,
        val locked: Int = 0,
        val invalid: Int = 0,
        val error: Int = 0,
        val nitroCount: Int = 0,
        val running: Boolean = false,
        val results: List<Result> = emptyList(),
    ) {
        val pct: Int get() = if (total == 0) 0 else (done * 100 / total)
    }

    private val _state = MutableStateFlow(State(total = tokens.size))
    val state: StateFlow<State> = _state.asStateFlow()

    private val valid = AtomicInteger(0)
    private val locked = AtomicInteger(0)
    private val invalid = AtomicInteger(0)
    private val errCount = AtomicInteger(0)
    private val nitroCount = AtomicInteger(0)
    private val done = AtomicInteger(0)

    private val results = mutableListOf<Result>()
    private val resultsLock = Mutex()

    private var proxyIdx = 0
    private fun nextProxy(): String? {
        if (proxies.isEmpty()) return null
        val p = proxies[proxyIdx % proxies.size]
        proxyIdx++
        return p
    }

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    /** 토큰 1개 체크 - V4NSH4J 식 분류. */
    private fun checkOne(token: String, proxy: String?): Result {
        return try {
            val req = Request.Builder()
                .url("https://discord.com/api/v9/users/@me/settings")
                .get()
                .header("Authorization", token)
                .header("User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                    "AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36")
                .build()
            client.newCall(req).execute().use { r ->
                val body = r.body?.string() ?: ""
                when {
                    r.code == 200 -> {
                        // 유효 - /users/@me 추가 호출로 상세 정보
                        fetchDetails(token, proxy)
                    }
                    "verify your account" in body.lowercase() ->
                        Result(token, "locked")
                    r.code == 401 -> Result(token, "invalid")
                    r.code == 403 -> Result(token, "locked")
                    r.code == 429 -> Result(token, "error")  // 레이트 리밋
                    else -> Result(token, "error")
                }
            }
        } catch (_: Exception) {
            Result(token, "timeout")
        }
    }

    /** /users/@me 로 계정 상세 조회. */
    private fun fetchDetails(token: String, proxy: String?): Result {
        return try {
            val req = Request.Builder()
                .url("https://discord.com/api/v9/users/@me")
                .get()
                .header("Authorization", token)
                .header("User-Agent",
                    "Mozilla/5.0 Chrome/126.0.0.0")
                .build()
            client.newCall(req).execute().use { r ->
                if (r.code != 200) return Result(token, "valid")
                val j = JSONObject(r.body?.string() ?: "{}")
                Result(
                    token = token,
                    status = "valid",
                    username = j.optString("username").ifEmpty { null },
                    id = j.optString("id").ifEmpty { null },
                    email = j.optString("email", null),
                    phone = j.optString("phone", null),
                    mfa = j.optBoolean("mfa_enabled", false),
                    nitro = j.optInt("premium_type", 0),
                    verified = j.optBoolean("verified", false),
                )
            }
        } catch (_: Exception) {
            Result(token, "valid")
        }
    }

    /** 메인 실행 - 병렬 체크. */
    suspend fun run() = coroutineScope {
        _state.value = _state.value.copy(running = true, total = tokens.size)

        val sem = kotlinx.coroutines.sync.Semaphore(parallel)
        val jobs = tokens.map { token ->
            async(Dispatchers.IO) {
                sem.acquire()
                try {
                    val proxy = nextProxy()
                    val r = checkOne(token, proxy)
                    when (r.status) {
                        "valid" -> { valid.incrementAndGet()
                            if (r.nitro > 0) nitroCount.incrementAndGet() }
                        "locked" -> locked.incrementAndGet()
                        "invalid" -> invalid.incrementAndGet()
                        else -> errCount.incrementAndGet()
                    }
                    resultsLock.withLock { results.add(r) }
                    done.incrementAndGet()
                    r
                } finally { sem.release() }
            }
        }

        // 진행 상태 발행 루프
        val progressJob = launch {
            while (done.get() < tokens.size) {
                delay(300)
                _state.value = State(
                    done = done.get(),
                    total = tokens.size,
                    valid = valid.get(),
                    locked = locked.get(),
                    invalid = invalid.get(),
                    error = errCount.get(),
                    nitroCount = nitroCount.get(),
                    running = true,
                    results = resultsLock.withLock { results.toList() },
                )
            }
        }

        jobs.awaitAll()
        progressJob.cancel()

        _state.value = State(
            done = done.get(),
            total = tokens.size,
            valid = valid.get(),
            locked = locked.get(),
            invalid = invalid.get(),
            error = errCount.get(),
            nitroCount = nitroCount.get(),
            running = false,
            results = resultsLock.withLock { results.toList() },
        )
    }
}
