// LEVIATHANIC 토큰 생성기 - 루트 빌드 스크립트
// 제작자 제프리 - https://discord.gg/leviathanic

plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}

tasks.register("clean", Delete::class) {
    delete(rootProject.buildDir)
}
